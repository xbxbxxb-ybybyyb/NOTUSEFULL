import argparse
import sys
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from operator import itemgetter
import matplotlib.backends.backend_pdf


start_date = '20170101'
end_date = '20201231'

def LoadScore(df, tp):
  if (tp == 'TYPE1'):#difference of first half skew and second half skew
    r = df.shape[0]
    df1 = df.iloc[0:r // 2, :]
    df2 = df.iloc[r // 2:-1, :]
    sk1 = df1.skew(axis=1)
    sk2 = df2.skew(axis=1)
    local_score = np.abs(np.nanmean(sk1) - np.nanmean(sk2))
    return local_score
  elif (tp == 'TYPE2'):#std of skew each day
    r = df.shape[0]
    sk = df.skew(axis=1)
    local_score = np.std(sk)
    return local_score
  elif (tp == 'TYPE3'):#smooth of hist
    r = df.shape[0]
    sk = df.skew(axis=1)
    local_score = np.std(sk)
    sdf = df.stack()
    count, division = np.histogram(sdf, bins=100)
    s = pd.DataFrame({'c':count})
    s['d'] = np.abs(s['c'] - s['c'].shift(1))
    local_score = s['d'].sum() / s['c'].sum()
    return local_score
  elif (tp == 'TYPE4'):#smooth of hist
    r = df.shape[0]
    sk = df.skew(axis=1)
    local_score = np.std(sk)
    r = df.shape[0]
    df1 = df.iloc[0:r // 2, :]
    df2 = df.iloc[r // 2:-1, :]
    sdf1 = df1.stack()
    sdf2 = df2.stack()
    count1, division1 = np.histogram(sdf1, bins=50)
    count2, division2 = np.histogram(sdf2, bins=50)
    s = pd.DataFrame({'c1':count1, 'c2':count2})
    s['d'] = np.abs(s['c1'] - s['c2'])
    local_score = s['d'].sum() / (s['c1'].sum() + s['c2'].sum())
    return local_score

  elif (tp == 'TYPE5'):#difference of first half kurt and second half kurt
    r = df.shape[0]
    #print(df)
    #input()
    df1 = df.iloc[0:r // 2, :]
    df2 = df.iloc[r // 2:-1, :]
    sk1 = df1.kurt(axis=1)
    sk2 = df2.kurt(axis=1)
    #print(sk1)
    #print(sk2)
    local_score = np.abs(np.nanmean(sk1) - np.nanmean(sk2))
    return local_score
  elif (tp == 'TYPE6'):#std of kurt each day
    r = df.shape[0]
    sk = df.kurt(axis=1)
    local_score = np.std(sk)
    return local_score
  elif (tp == 'TYPE7'):#std of kurt each day
    r = df.shape[0]
    sk = df.kurt(axis=1)
    sk = sk - sk.shift(1)
    sk = np.abs(sk)
    local_score = np.mean(sk)
    return local_score
  elif (tp == 'TYPE8'):#std of kurt each day
    r = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk - sk.shift(1)
    sk = np.abs(sk)
    local_score = np.mean(sk)
    return local_score

def LoadFactor(prefix, tp):
    res = []
    for root,dirs,files in os.walk(prefix): 
       #for dir in dirs: 
       #    print os.path.join(root,dir).decode('gbk').encode('utf-8'); 
       for f in files: 
         print(f)
         f = f.strip()
         f = f.split('.')[0]
         #print os.path.join(root,file).decode('gbk').encode('utf-8');
         df = pd.read_pickle(prefix + f +'.pkl').loc[start_date:end_date]
         local_score = LoadScore(df, tp)
         res.append([local_score, f])
         #if (len(res) > 20):
         #  break
         #input()

    
    res.sort(key=itemgetter(0,1), reverse=True)
    fn = []
    for i in res:fn.append(i[1])
    score = []
    for i in res:score.append(i[0])
    return score, fn
    

def PlotPdf(prefix, output, tp):
    factor_score, factor_list = LoadFactor(prefix, tp)
    with matplotlib.backends.backend_pdf.PdfPages(output + '.pdf') as pdf:
        for i in range(int(len(factor_list)/9) + 1):
            fig = plt.figure(figsize=(15, 15))
            fig.tight_layout()
            plot_num = 331
            for j in range(9 * i, 9 * (i + 1)):
                if j < len(factor_list):
                    plt.subplot(plot_num)
                    f = factor_list[j]#%excessReturn.columns[j]
                    print(f)
                    df = pd.read_pickle(prefix + f + '.pkl').loc[start_date:end_date]
                    #plt.hist(df.stack().values,bins=100)

                    r = df.shape[0]
                    df1 = df.iloc[0:r // 2, :]
                    df2 = df.iloc[r // 2:-1, :]

                    plt.hist(df1.stack().values, bins=100, alpha=0.5, label='first half')
                    plt.hist(df2.stack().values, bins=100, alpha=0.5, label='second half')

                    plt.title(factor_list[j])
                    plot_num += 1
            plt.rcParams.update({'font.size': 8})
            pdf.savefig(fig)
    f = open(output + '.csv', 'w')
    for i in range(len(factor_list)):
      f.write(str(factor_score[i]) + ',' + factor_list[i] + '\n')
    f.close()

    



if __name__=="__main__":
    args = argparse.ArgumentParser(description = 'dftotrain',epilog = 'Information end ')
    args.add_argument("--input", type=str, dest='input', default='/data/group/800020/AlphaExperiment/neutral_factor_grow/', help = "input csv")
    args.add_argument("--output", type=str, dest='output', default='/data/user/012316/output', help = "output pdf")



    args.add_argument("--return", type=str, dest='return', default='/home/yzhan/CPP/exprgen/DUMPCSV/DATA/ret', help = "target csv")
    args.add_argument("--cap", type=str, dest='cap', default='/home/yzhan/CPP/exprgen/DUMPCSV/DATA/cap', help = "cap csv")


    args.add_argument("--type", type=str, dest='type', default='raw', help = "")

    args = args.parse_args()#返回一个命名空间,如果想要使用变量,可用args.attr
    d = args.__dict__
    ifile = d['input'] 
    ofile = d['output'] 
    ret = d['return'] 
    cap = d['cap'] 
    tp = d['type'] 
    base = os.path.basename(ifile).split('.')[0]
    
    
    #sig_csv = pd.read_csv(ifile, index_col=0, low_memory=False).apply(pd.to_numeric, errors='coerce')
    #sig_csv = pd.read_pickle(ifile)

    
    PlotPdf(d['input'], d['output'], d['type'])
    
