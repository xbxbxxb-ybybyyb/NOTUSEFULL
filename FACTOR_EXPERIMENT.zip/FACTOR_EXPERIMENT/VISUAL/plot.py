#!/bin/python3

#usage 1:
#[appadmin@docker-msvzn x_factor_lib]$ cat /tmp/list|xargs -n 1 python3 /tmp/test.py --input^C
#usage 2:
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}

import pandas as pd
import sys
import os, errno
import argparse
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

import numpy as np
from numpy.linalg import svd

#pd.set_option('display.max_columns',None)
#pd.set_option('display.max_rows',100)


def mkdir_p(path):
    if (path[-1] != '/'):
        print('skip:' + path)
        return
    try:
        os.makedirs(path)
    except OSError as exc: # Python >2.5 (except OSError, exc: for Python <2.5)
        if exc.errno == errno.EEXIST and os.path.isdir(path):
            pass
        else: raise

def DateSet(sig, target):
    ser1 = sig.index
    ser2 = target.index
    i = pd.Series(np.intersect1d(ser1, ser2))
    return i
    
def IISet(sig, target):
    ser1 = sig.columns
    ser2 = target.columns
    i = pd.Series(np.intersect1d(ser1, ser2))
    return i


def Shrink(sig, target):
    dateset = DateSet(sig, target)
    target = target.loc[dateset,:]
    sig = sig.loc[dateset,:]
    iiset = IISet(sig, target)
    target = target[iiset]
    sig = sig[iiset]
    return sig, target



def PlotRaw(input_csv, output_dir, name, prefix):
    plt.figure(figsize=(100, 100))
    
    input_csv = input_csv.iloc[:, :500]
    df = input_csv.reset_index(drop=True)
    print('start')
    df.plot(legend=False, lw=0.1)
    print('end')
    mkdir_p(output_dir + '/' + prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')

def PlotMean(input_csv, output_dir, name, prefix, axis):
    df = input_csv.reset_index(drop=True)
    mean = df.mean(axis=axis)
    mean = (mean.dropna())
    if (axis == 0):
        mean = mean.reset_index(drop=True)
    #print(mean)
    plt.figure(figsize=(100, 100))
    ans = pd.DataFrame(np.zeros((mean.shape[0], 1)))
    ans[0] = list(mean)
    ans.plot(legend=False, lw=1, color='r')

    #mean.plot(legend=False, lw=0.1, color='r')
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')

def PlotSigma(input_csv, output_dir, name, prefix, axis, xtext, ytext, title):
    plt.figure(figsize=(100, 100))
    df = input_csv.reset_index(drop=True)
    sigma = df.std(axis=axis)
    sigma = sigma.dropna()
    if (axis == 0):
        sigma = sigma.reset_index(drop=True)
    ans = pd.DataFrame(np.zeros((sigma.shape[0], 1)))
    ans[0] = list(sigma)
    ans.plot(legend=False, lw=1, color='r')
    plt.xlabel(xtext)
    plt.ylabel(ytext)
    plt.title(title)
    #sigma.plot(legend=False, lw=2, color='r')
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')
    of = open(output_dir + '/' + prefix + name + '.txt', 'w')
    of.write(str(np.nanmean(ans.abs().sum())))
    of.close()

def PlotSkew(input_csv, output_dir, name, prefix, axis, xtext, ytext, title):
    plt.figure(figsize=(100, 100))
    df = input_csv.reset_index(drop=True)
    sigma = df.skew(axis=axis)
    sigma = sigma.dropna()
    if (axis == 0):
        sigma = sigma.reset_index(drop=True)
    ans = pd.DataFrame(np.zeros((sigma.shape[0], 1)))
    ans[0] = list(sigma)
    ans.plot(legend=False, lw=1, color='r')
    plt.xlabel(xtext)
    plt.ylabel(ytext)
    plt.title(title)
    #sigma.plot(legend=False, lw=2, color='r')
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')
    of = open(output_dir + '/' + prefix + name + '.txt', 'w')
    of.write(str(np.nanmean(ans.abs().sum())))
    of.close()

def Clean(X):
    X = X.replace(-np.inf,np.nan)
    X = X.replace(np.inf,np.nan)
    X = X.replace(-np.nan,np.nan)
    return X

def PlotHist(input_csv, output_dir, name, prefix, axis, xtext, ytext, title):
    plt.figure(figsize=(10, 10))
    df = input_csv.reset_index(drop=True)
    df = Clean(df)
    
    
    sigma = df.skew(axis=axis)
    sigma = sigma.dropna()
    if (axis == 0):
        sigma = sigma.reset_index(drop=True)
    ans = pd.DataFrame(np.zeros((sigma.shape[0], 1)))
    ans[0] = list(sigma)
    #ans.plot(legend=False, lw=1, color='r')
    df = df.stack()
    n, bins, patches = plt.hist(list(df), 50, density = True,color = 'green')
    #plt.xlabel(xtext)
    #plt.ylabel(ytext)
    plt.title(title)
    
    #print(ans)
    #exit(0)

    #sigma.plot(legend=False, lw=2, color='r')
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')
    of = open(output_dir + '/' + prefix + name + '.txt', 'w')
    of.write(str(np.nanmean(ans.abs().sum())))
    of.close()
    
    
def PlotDW(input_csv, output_dir, name, prefix, axis):
    plt.figure(figsize=(100, 100))
    df = input_csv.reset_index(drop=True)
    df = df.dropna(axis=0,how='all')
    df = df.dropna(axis=1,how='all')
    e1 = df.shift(1)
    up = df - e1
    up = up.pow(2)
    down = df.pow(2)
    up = up.rolling(50,min_periods=30).mean()
    down = down.rolling(50,min_periods=30).mean()
    dw = up / down - 2
    dw.plot(legend=False, lw=0.1)
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')
def PlotDWMean(input_csv, output_dir, name, prefix, axis):
    plt.figure(figsize=(100, 100))
    df = input_csv.reset_index(drop=True)
    df = df.dropna(axis=0,how='all')
    df = df.dropna(axis=1,how='all')
    e1 = df.shift(1)
    up = df - e1
    up = up.pow(2)
    down = df.pow(2)
    up = up.rolling(50,min_periods=30).mean()
    down = down.rolling(50,min_periods=30).mean()
    dw = up / down - 2

    mean = dw.mean(axis=axis)
    mean = mean.dropna()

    ans = pd.DataFrame(np.zeros((mean.shape[0], 1)))
    ans[0] = list(mean)
    ans.plot(legend=False, lw=1, color='r')

    #mean.plot(legend=False, lw=2, color='r')

    #dw.plot(legend=False, lw=0.1)
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')

def PlotEigen(input_csv, output_dir, name, prefix, axis):
    plt.figure(figsize=(100, 100))
    df = input_csv.reset_index(drop=True)
    df = df.dropna(axis=0,how='all')
    #df = df.dropna(axis=1,how='all')
    #m0 = df.mean().mean()
    #df = df.fillna(m0)
    inc = 20
    ans = pd.DataFrame(np.zeros((df.shape[0] // inc, 5)))
    
    for i in range(df.shape[0] // inc):
        start = i * inc
        end = i * inc + inc
        ld = df.iloc[start:end, :]

        ld = ld.dropna(axis=0,how='all')
        ld = ld.dropna(axis=1,how='all')
        m0 = ld.mean().mean()
        ld = ld.fillna(m0)

        a = ld.values
        aa = a.dot(a.T)
        ww,dd,vv = svd(aa)
        eigsum = 0
        for j in range(len(dd)): 
            eigsum = eigsum + dd[j]
        for j in range(5): 
            ans.iloc[i, j] = dd[j] / eigsum
        
    ans.plot(legend=False, lw=1)
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')

def PlotCorr(input_csv, output_dir, name, prefix, axis):
    plt.figure(figsize=(100, 100))
    df = input_csv.reset_index(drop=True)
    df = df.dropna(axis=0,how='all')
    inc = 20
    ans = pd.DataFrame(np.zeros((df.shape[0] // inc, 4)))
    
    for i in range(df.shape[0] // inc):
        start = i * inc
        end = i * inc + inc
        ld = df.iloc[start:end, :]

        ld = ld.dropna(axis=0,how='all')
        ld = ld.dropna(axis=1,how='all')
        m0 = ld.mean().mean()
        ld = ld.fillna(m0)
        lc = (ld.corr().stack())
        v = np.percentile(lc, q = [25, 50, 75, 90])
        ans.iloc[i, 0] = v[0]
        ans.iloc[i, 1] = v[1]
        ans.iloc[i, 2] = v[2]
        ans.iloc[i, 3] = v[3]
        
        
    ans.plot(legend=False, lw=1)
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')

def PlotCap(cap_csv, input_csv, output_dir, name, prefix, axis):
    plt.figure(figsize=(100, 100))
    sig1 = input_csv.dropna(axis=0,how='all')
    sig2 = cap_csv.dropna(axis=0,how='all')
    sig1, sig2 = Shrink(sig1, sig2)
    corr = sig1.corrwith(sig2, axis=1)
    ans = pd.DataFrame(np.zeros((sig1.shape[0], 0)))
    ans[0] = list(corr)
    #print(ans.shape)
    ans.plot(legend=False, lw=1, color='r')
    mkdir_p(output_dir + '/' +prefix)
    plt.savefig(output_dir + '/' + prefix + name + '.jpg')
    print('save to ' + output_dir + '/' +prefix + name + '.jpg')
    

if __name__=="__main__":
    args = argparse.ArgumentParser(description = 'dftotrain',epilog = 'Information end ')
    args.add_argument("--input", type=str, dest='input', default='/home/yzhan/CACHE/yzhantmp/DUMPS/dmgr_yzhan_taq_sig5_svd2/dmgr_yzhan_taq_sig5_svd2.csv', help = "input csv")
    args.add_argument("--output", type=str, dest='output', default='/tmp/DATA/IMAGE_NEU', help = "output csv")
    args.add_argument("--return", type=str, dest='return', default='/home/yzhan/CPP/exprgen/DUMPCSV/DATA/ret', help = "target csv")
    args.add_argument("--cap", type=str, dest='cap', default='/home/yzhan/CPP/exprgen/DUMPCSV/DATA/cap', help = "cap csv")


    args.add_argument("--type", type=str, dest='type', default='raw', help = "")

    args = args.parse_args()#返回一个命名空间,如果想要使用变量,可用args.attr
    d = args.__dict__
    ifile = d['input'] 
    ofile = d['output'] 
    ret = d['return'] 
    cap = d['cap'] 
    tp = d['type'] 
    base = os.path.basename(ifile).split('.')[0]
    
    
    #sig_csv = pd.read_csv(ifile, index_col=0, low_memory=False).apply(pd.to_numeric, errors='coerce')
    sig_csv = pd.read_pickle(ifile)

    #sig_csv = sig_csv.apply(pd.to_numeric, errors='coerce')

    #ret_csv = pd.read_csv(ret, index_col=0)
    #cap_csv = pd.read_csv(cap, index_col=0).rank(axis=1)

    
    if (tp == 'raw'):
        PlotRaw(sig_csv, ofile, base, 'RAW/')
    elif (tp == 'mean'):
        PlotMean(sig_csv, ofile, base, 'MEAN/', 0)#x=ticker
    elif (tp == 'meant'):
        PlotMean(sig_csv, ofile, base, 'MEANT/', 1)#x=time
    elif (tp == 'sigma'):
        PlotSigma(sig_csv, ofile, base, 'SIGMA/', 0, 'x=ticker', 'sigma', base)#x=ticker
    elif (tp == 'sigmat'):
        PlotSigma(sig_csv, ofile, base, 'SIGMAT/', 1, 'x=time', 'sigma', base)#x=time
    elif (tp == 'skew'):
        PlotSkew(sig_csv, ofile, base, 'SKEW/', 0, 'x=ticker', 'skewness', base)#x=ticker
    elif (tp == 'skewt'):
        PlotSkew(sig_csv, ofile, base, 'SKEWT/', 1, 'x=time', 'skewness', base)#x=time
    elif (tp == 'hist'):
        PlotHist(sig_csv, ofile, base, 'HIST/', 1, 'x=time', 'hist', base)#x=time
    elif (tp == 'dw'):
        PlotDW(sig_csv, ofile, base, 'DW/', 0)#x=ticker
    elif (tp == 'dwmean'):
        PlotDWMean(sig_csv, ofile, base, 'DWMEAN/', 1)#x=time
    elif (tp == 'eigen'):
        PlotEigen(sig_csv, ofile, base, 'EIGEN/', 0)#x=ticker
    elif (tp == 'corr'):
        PlotCorr(sig_csv, ofile, base, 'CORR/', 0)#x=ticker
    elif (tp == 'cap'):
        cap_csv = pd.read_csv(cap, index_col=0).rank(axis=1)
        PlotCap(cap_csv, sig_csv, ofile, base, 'CAP/', 0)#x=ticker
    
    elif (tp == 'all'):
        PlotRaw(sig_csv, ofile, base, 'RAW/')
        PlotMean(sig_csv, ofile, base, 'MEAN/', 0)#x=ticker
        PlotMean(sig_csv, ofile, base, 'MEANT/', 1)#x=time
        PlotSigma(sig_csv, ofile, base, 'SIGMA/', 0)#x=ticker
        PlotSigma(sig_csv, ofile, base, 'SIGMAT/', 1)#x=time
        PlotDW(sig_csv, ofile, base, 'DW/', 0)#x=ticker
        PlotDWMean(sig_csv, ofile, base, 'DWMEAN/', 1)#x=time
        PlotEigen(sig_csv, ofile, base, 'EIGEN/', 0)#x=ticker
        PlotCorr(sig_csv, ofile, base, 'CORR/', 0)#x=ticker
        cap_csv = pd.read_csv(cap, index_col=0).apply(pd.to_numeric, errors='coerce').rank(axis=1)
        PlotCap(cap_csv, sig_csv, ofile, base, 'CAP/', 0)#x=ticker
