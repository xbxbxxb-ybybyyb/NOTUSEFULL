

#/data/group/800020/AlphaDataCenter/NeuFactor/
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}
#python3 plot.py --input /data/group/800020/AlphaDataCenter/NeuFactor/AccountPayableTurn_ttm_tsrank4.pkl --type skewt --output IMAGE
#python3 plot.py --input /data/group/800020/AlphaDataCenter/NeuFactor/AccountPayableTurn_ttm_tsrank4.pkl --type skewt --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skewt --output IMAGE



#python3 plot.py --input /data/group/800020/AlphaDataCenter/NeuFactor/AccountPayableTurn_ttm_tsrank4.pkl --type hist --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type hist --output IMAGE

#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigma --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigmat --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skew --output IMAGE
#/data/group/800020/AlphaDataCenter/Factor/daily/


#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigma --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigmat --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skew --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skewt --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type hist --output Facotr_daily


#python3 plot.py --input /data/group/800020/AlphaDataCenter/Factor/daily/WQ_044.pkl --type hist --output IMAGE


python3 topdf.py --output PDF/TYPE1/TYPE1 --type TYPE1&
python3 topdf.py --output PDF/TYPE1/TYPE2 --type TYPE2&
python3 topdf.py --output PDF/TYPE1/TYPE3 --type TYPE3&
python3 topdf.py --output PDF/TYPE1/TYPE4 --type TYPE4&
python3 topdf.py --output PDF/TYPE1/TYPE5 --type TYPE5&
python3 topdf.py --output PDF/TYPE1/TYPE6 --type TYPE6&
python3 topdf.py --output PDF/TYPE1/TYPE7 --type TYPE7&
python3 topdf.py --output PDF/TYPE1/TYPE8 --type TYPE8&

