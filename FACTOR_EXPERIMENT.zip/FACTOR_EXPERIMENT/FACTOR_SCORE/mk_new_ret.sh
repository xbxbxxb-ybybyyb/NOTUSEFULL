python3 mk_new_ret.py 2 50&
python3 mk_new_ret.py 3 50&
python3 mk_new_ret.py 4 50&
python3 mk_new_ret.py 2 80&
python3 mk_new_ret.py 3 80&
python3 mk_new_ret.py 4 80&
wait
