#compare min(400 day ret, short term ret) with bench
import pandas as pd
import numpy as np
ret=pd.read_pickle('factor_depart_size_neu_excess.pkl')
ret_adj=pd.read_pickle('ADJ_RET/adj_ret_80_3.pickle')
#ret_adj=pd.read_csv('ADJ_RET/adj_ret_2_50.csv', index_col=0)
#print(ret_adj)
#input()
import sys

f = sys.argv[1]
sc = pd.read_csv('OUTPUT/TYPE1.csv', index_col=0)
sc.index = pd.DatetimeIndex(sc.index)
mp = {}
mp['TYPE60'] = 80
mp['TYPE61'] = 120
mp['TYPE62'] = 160
mp['TYPE63'] = 200
mp['TYPE64'] = 240
mp['TYPE65'] = 280
mp['TYPE66'] = 320
mp['TYPE67'] = 360
mp['TYPE68'] = 400
mp['TYPE69'] = 440
ssz = mp[f]


col1 = set(ret.columns)
col2 = set(sc.columns)
col = list(col1 & col2)
ret = ret[col]
sc= sc[col]
sc = sc.rank(axis=1) / sc.shape[1]

#print(ret)
#print(sc)
#input()

retroll = ret.rolling(window=400).mean()
ret_short = ret_adj.rolling(window=ssz).mean()
print(ret_short)
#input()

retroll = retroll.shift(3)
ret_short = ret_short.shift(3)

sc = sc.rolling(window=100, min_periods=1).mean()


retroll = retroll.loc[sc.index]
ret = ret.loc[sc.index]
ret_short = ret_short.loc[sc.index]
print(retroll)

assert(retroll.shape[0] == ret_short.shape[0])
assert(retroll.shape[0] == ret.shape[0])
assert(retroll.shape[0] == sc.shape[0])


#res = pd.DataFrame()
#res.index = retroll.index
#print(res)
#input()



idx = []
v0 = []
v1 = []


for i in range(retroll.shape[0] - 40):
  r = retroll.iloc[i, :] 
  r = r.sort_values(ascending=False)
  #print(r)
  #input()
  s = i
  e = i + 6
  good = r.index[0:1000]
  local = ret
  local = local.iloc[s:e]
  #print(local)
  #input()
  m0 = np.mean(local.mean())
  v0.append(m0)
  
  #print(retroll.iloc[i, :])
  #print(1 - sc.iloc[i, :] * 0.1)
  #input()
  r1 = retroll.iloc[i, :]
  r2 = ret_short.iloc[i, :]
  local_df = pd.DataFrame({'r1':r1, 'r2':r2})
  r = local_df['r2']#local_df.min(axis=1)
  #print(r)
  
  r = r.sort_values(ascending=False)
  #print(r)
  #input()
  s = i
  e = i + 6
  good = r.index[0:1000]
  local = ret[good]
  local = local.iloc[s:e]
  #print(local)
  #input()
  m1 = np.mean(local.mean())
  v1.append(m1)
  idx.append(retroll.index[i])
  
  
  
  
  




res = pd.DataFrame({'bench':v0, 'adj':v1}, index=idx)

res['diff'] = res['adj'] - res['bench']
res['cumdiff'] = res['diff'].cumsum()
print(res)


res.to_csv('OUTPUT' + '/' + f + '_res.csv')
