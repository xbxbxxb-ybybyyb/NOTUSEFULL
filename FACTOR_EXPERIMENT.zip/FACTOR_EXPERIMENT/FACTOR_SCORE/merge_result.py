import pandas as pd
import argparse
import sys
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from operator import itemgetter
import matplotlib.backends.backend_pdf

import matplotlib.ticker as ticker
matplotlib.rcParams['font.family'] = 'SimHei'



#s = [10, 20, 40, 60, 80]
#tp = [1, 2, 3, 4, 5, 6]
#
#algo = ['XgboostRegression', 'LinearRegression']
#s = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
#algo = ['XgboostRegression']

res = []
for t in range(70):
  a = pd.read_csv('OUTPUT/TYPE' + str(t) + '_res.csv', index_col=0)
  #print(a.index)
  #print(a['cumdiff'])
  #input()
  res.append([list(a.index), list(a['cumdiff']), 'TYPE' + str(t)])








output = 'FACTOR_EXPERIMENT'


with matplotlib.backends.backend_pdf.PdfPages(output + '.pdf') as pdf:
    for i in range(int(len(res)/9) + 1):
        fig = plt.figure(figsize=(15, 15))
        fig.tight_layout()
        plot_num = 331
        for j in range(9 * i, 9 * (i + 1)):
            if j < len(res):
                plt.subplot(plot_num)
                #f = factor_list[j]#%excessReturn.columns[j]
                #print(f)
                #df = pd.read_pickle(prefix + f + '.pkl').loc[start_date:end_date]
                ##plt.hist(df.stack().values,bins=100)

                #r = df.shape[0]
                #df1 = df.iloc[0:r // 2, :]
                #df2 = df.iloc[r // 2:-1, :]

                #plt.hist(df1.stack().values, bins=100, alpha=0.5, label='first half')
                #plt.hist(df2.stack().values, bins=100, alpha=0.5, label='second half')
                plt.plot(res[j][0], res[j][1], '-')
                #[0, 6, 12, 36, 48], [0, 6, 12, 36, 48]
                v = res[j][0]
                plt.xticks(list(range(0,len(v), 200)), v[0:-1:200])

                #ax.xaxis.set_major_locator(ticker.MultipleLocator(base=50))
                plt.title(res[j][2])
                plt.xlabel('time')
                plt.ylabel('cum diff of newscore / bench')
                plot_num += 1
        plt.rcParams.update({'font.size': 8})
        pdf.savefig(fig)

    fig = plt.figure(figsize=(15, 15))
    x = np.linspace(0.05, 10, 1000)
    y = np.sin(x)
    #plt.plot(x, y, ls="-.", lw=2, c="c", label="plot figure")
    #plt.legend()
    plt.text(0, 0.9, "TYPE0 score = rolling 400 day's accret * (1 - rank of skewness' std for past 40 days)  [idea accret weighted by stableness of skewness]", weight="bold", color="b")
    plt.text(0, 0.89, "TYPE1 score = rolling 400 day's accret * (1 - rank of skewness' std for past 80 days)", weight="bold", color="b")
    plt.text(0, 0.88, "TYPE2 score = rolling 400 day's accret * (1 - rank of skewness' std for past 120 days)", weight="bold", color="b")
    plt.text(0, 0.87, "TYPE3 score = rolling 400 day's accret * (1 - rank of skewness' std for past 240 days)", weight="bold", color="b")

    plt.text(0, 0.86, "TYPE4 score = rolling 400 day's accret * (1 - rank of kurt' std for past 40 days)[idea accret weighted by stableness of kurt]", weight="bold", color="b")
    plt.text(0, 0.85, "TYPE5 score = rolling 400 day's accret * (1 - rank of kurt' std for past 80 days)", weight="bold", color="b")
    plt.text(0, 0.84, "TYPE6 score = rolling 400 day's accret * (1 - rank of kurt' std for past 120 days)", weight="bold", color="b")
    plt.text(0, 0.83, "TYPE7 score = rolling 400 day's accret * (1 - rank of kurt' std for past 240 days)", weight="bold", color="b")

    plt.text(0, 0.82, "TYPE8 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 40 days) [idea accret weighted by each stock's mean value]", weight="bold", color="b")
    plt.text(0, 0.81, "TYPE9 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 80 days)", weight="bold", color="b")
    plt.text(0, 0.80, "TYPE10 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 120 days)", weight="bold", color="b")
    plt.text(0, 0.79, "TYPE11 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 240 days)", weight="bold", color="b")

    plt.text(0, 0.78, "TYPE12 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 40 days) [idea accret weighted by each stock's std's]", weight="bold", color="b")
    plt.text(0, 0.77, "TYPE13 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 80 days)", weight="bold", color="b")
    plt.text(0, 0.76, "TYPE14 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 120 days)", weight="bold", color="b")
    plt.text(0, 0.75, "TYPE15 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 240 days)", weight="bold", color="b")

    plt.text(0, 0.74, "TYPE16 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 40 days) [idea accret weighted by each stock's std(similar as previous)]", weight="bold", color="b")
    plt.text(0, 0.73, "TYPE17 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 80 days)", weight="bold", color="b")
    plt.text(0, 0.72, "TYPE18 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 120 days)", weight="bold", color="b")
    plt.text(0, 0.71, "TYPE19 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 240 days)", weight="bold", color="b")

    plt.text(0, 0.70, "BENCHMARK is using rolling 400 day's accret, rank the factor and pick the top 1000 factors, then calculate BASELINE = next 30day's average ret")
    plt.text(0, 0.69, "COMPARISON is using new score, rank the factor and pick the top 1000 factors, then calculate COMPARISON=next 30day's average ret")
    plt.text(0, 0.68, "each plot is COMPARISON / BASELINE - 1's cumsum")
    plt.text(0, 0.57, "TYPE20-29 min(kday ret, 400day ret) k = 40 60 ..220 ")
    plt.text(0, 0.56, "TYPE30-39 mean(kday ret, 400day ret) k = 40 60 ..220 ")
    plt.text(0, 0.55, "TYPE40-49 mean(k day ret) / std(k day ret) k = 50 100 ..500 ")
    plt.text(0, 0.54, "TYPE50-59 median(k day ret) / std(k day ret) k = 50 100 ..500 ")
    

    pdf.savefig(fig)
  
#f = open(output + '.csv', 'w')
#for i in range(len(factor_list)):
#  f.write(str(factor_score[i]) + ',' + factor_list[i] + '\n')
#f.close()

        
  
