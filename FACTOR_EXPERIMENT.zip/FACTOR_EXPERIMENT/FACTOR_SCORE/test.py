#import pickle
#f = open('factor_depart_size_neu_excess.pkl','rb')
#c = pickle.load(f)
#f.close()
#print(c)
#input()

import pandas as pd
import numpy as np
ret=pd.read_pickle('factor_depart_size_neu_excess.pkl')
print(ret)
