

#/data/group/800020/AlphaDataCenter/NeuFactor/
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}
#python3 plot.py --input /data/group/800020/AlphaDataCenter/NeuFactor/AccountPayableTurn_ttm_tsrank4.pkl --type skewt --output IMAGE
#python3 plot.py --input /data/group/800020/AlphaDataCenter/NeuFactor/AccountPayableTurn_ttm_tsrank4.pkl --type skewt --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skewt --output IMAGE



#python3 plot.py --input /data/group/800020/AlphaDataCenter/NeuFactor/AccountPayableTurn_ttm_tsrank4.pkl --type hist --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type hist --output IMAGE

#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigma --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigmat --output IMAGE
#ls /data/group/800020/AlphaDataCenter/NeuFactor/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skew --output IMAGE
#/data/group/800020/AlphaDataCenter/Factor/daily/


#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigma --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type sigmat --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skew --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type skewt --output Facotr_daily
#ls /data/group/800020/AlphaDataCenter/Factor/daily/* |xargs -n 1 -I {} python3 plot.py --input {}  --type hist --output Facotr_daily


#python3 plot.py --input /data/group/800020/AlphaDataCenter/Factor/daily/WQ_044.pkl --type hist --output IMAGE


#python3 topdf.py --output PDF/TYPE1/TYPE1 --type TYPE1&
#python3 topdf.py --output PDF/TYPE1/TYPE2 --type TYPE2&
#python3 topdf.py --output PDF/TYPE1/TYPE3 --type TYPE3&
#python3 topdf.py --output PDF/TYPE1/TYPE4 --type TYPE4&
#python3 topdf.py --output PDF/TYPE1/TYPE5 --type TYPE5&
#python3 topdf.py --output PDF/TYPE1/TYPE6 --type TYPE6&

#for ((i=0;i<19;++i));do
#python3 topdf.py --output OUTPUT/TYPE${i}.csv --type TYPE${i}
#done




#!/bin/bash
thread_num=10  # 最大可同时执行线程数量
job_num=20   # 任务总数
function my_cmd(){
  i=$1
  python3 topdf.py --output OUTPUT/TYPE${i}.csv --type TYPE${i}
  #echo "test"
  #t=$RANDOM
  #t=$[t%5]
  #sleep $t
  #echo "sleep $t s"
}
tmp_fifofile="/tmp/$$.fifo"
mkfifo $tmp_fifofile      # 新建一个fifo类型的文件
exec 6<>$tmp_fifofile     # 将fd6指向fifo类型
#rm $tmp_fifofile    #删也可以
#根据线程总数量设置令牌个数
for ((i=0;i<${thread_num};i++));do
    echo
done >&6
for ((i=0;i<${job_num};i++));do # 任务数量
    # 一个read -u6命令执行一次，就从fd6中减去一个回车符，然后向下执行，
    # fd6中没有回车符的时候，就停在这了，从而实现了线程数量控制
    read -u6
    #可以把具体的需要执行的命令封装成一个函数
    {
        my_cmd $i
        echo >&6 # 当进程结束以后，再向fd6中加上一个回车符，即补上了read -u6减去的那个
    } &
done

wait
exec 6>&- # 关闭fd6
echo "over"


