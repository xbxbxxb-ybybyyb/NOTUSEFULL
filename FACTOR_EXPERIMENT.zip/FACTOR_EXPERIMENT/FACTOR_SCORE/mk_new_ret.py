
# -*- coding: utf-8 -*- # @Time    : 2020/2/4 10:56
# @Author  : wangweidi
import pandas as pd
import numpy as np
from numpy.linalg import svd

from xquant.factordata import FactorData
s = FactorData()


import sklearn.linear_model as lm
from sklearn.linear_model import Ridge,RidgeCV

np.set_printoptions(threshold=np.inf)
pd.set_option('display.max_rows',2000)


def Clean(X):
    X = X.replace(-np.inf,np.nan)
    X = X.replace(np.inf,np.nan)
    X = X.replace(-np.nan,np.nan)
    return X
def Clean0(X):
    X = X.replace(-np.inf,0)
    X = X.replace(np.inf,0)
    X = X.replace(-np.nan,0)
    X = X.replace(np.nan,0)
    return X

def fill_ndarray(t1):
    for i in range(t1.shape[1]):  # 遍历每一列（每一列中的nan替换成该列的均值）
        temp_col = t1[:, i]  # 当前的一列
        nan_num = np.count_nonzero(temp_col != temp_col)
        if nan_num != 0:  # 不为0，说明当前这一列中有nan
            temp_not_nan_col = temp_col[temp_col == temp_col]  # 去掉nan的ndarray
            # 选中当前为nan的位置，把值赋值为不为nan的均值
            temp_col[np.isnan(temp_col)] = temp_not_nan_col.mean()  # mean()表示求均值。
    return t1
def MTA(d, rid, kp):
  from numpy.linalg import svd
  a = d.values
  mean = np.nanmean(a)
  if np.isnan(mean) == True: mean = 0
  a = d.fillna(mean).values
  aa = a.dot(a.T)
  ww,dd,vv = svd(aa)
  for i in range(len(dd)): dd[i] = np.sqrt(dd[i])
  nv = ww.T.dot(a)
  s = nv.shape
  height = s[0]
  width = s[1]
  for i in range(height):
    for j in range(width):
      if (np.abs(dd[i]) > 1e-9):
        nv[i][j] = nv[i][j] / dd[i]
  for i in range(len(dd)):
    if (i < kp): dd[i] = 0
  res = np.zeros([width], dtype='float64')
  for i in range(width):
    for j in range(height):
      res[i] = res[i] + dd[j] * ww[rid][j] * nv[j][i]
  return res


def ABC(Y, k, bd):
    row = Y.shape[0]
    col = Y.shape[1]
    #h,l = Y.shape
    residual = np.zeros([row, col])
    for i in range(bd,row):
        ##print(i)
        y = Y.iloc[i-bd:i+1,:]
        r = y.shape[0]
        im = MTA(y, r - 1, k)
        residual[i,:] = im
    
    ans = pd.DataFrame(residual)
    ans = Clean(ans)
    #rn = rn.replace([np.inf,-np.inf],[np.nan,np.nan])
    ans.columns = Y.columns
    ans.index = Y.index
    return ans




def DropNAN(X):
  data = X.replace(-np.inf,np.nan)
  data = data.replace(np.inf,np.nan)
  data = data.replace(-np.nan,np.nan)
  data = data.dropna(axis=1,how='all')#delete col contains all nan
  data = data.dropna(axis=0,how='all')#delete row contains all nan
  data = data.dropna(axis=1,how='any')#delete col contains any nan
  return data

#from DEBUG import *
  
def HIJ(Y, k, bd):
    row = Y.shape[0]
    col = Y.shape[1]
    ans = pd.DataFrame(np.zeros([row, col]))
    ans.columns = Y.columns
    ans.index = Y.index
    cnt = 0
    for i in range(bd,row):
        print(i)
        y = Y.iloc[i-bd:i+1,:]
        r = y.shape[0]
        ny = DropNAN(y)
        #print(ny)
        #DEBUG1(ny.stack(), str(y.index[-1])[:10])
        if (ny.shape[0] < k * 2):continue
        im = MTA(ny, ny.shape[0] - 1, k)
        #print(im)
        #input()
        for s in range(im.shape[0]):
          ans.loc[Y.index[i], ny.columns[s]] = im[s]
        cnt = cnt + 1
        #if (cnt > 10):
        #  break
    ans = Clean(ans)
    #print(ans)
    return ans



import sys
kp=int(sys.argv[1])
bd=int(sys.argv[2])

ret=pd.read_pickle('factor_depart_size_neu_excess.pkl')
res = HIJ(ret, kp, bd)


res.to_csv('adj_ret_' + str(bd) + '_' + str(kp) + '.csv', float_format="%.5f")
res.to_pickle('adj_ret_' + str(bd) + '_' + str(kp) + '.pickle')

    
