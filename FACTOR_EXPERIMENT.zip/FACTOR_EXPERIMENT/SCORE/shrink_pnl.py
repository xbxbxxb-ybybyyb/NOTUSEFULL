import argparse
import sys
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from operator import itemgetter
import matplotlib.backends.backend_pdf


# In[14]:
start_date = '20160101'
end_date = '20201231'




    

def factorlist(prefix, output, idx):
  a = []
  for root,dirs,files in os.walk(prefix): 
     for f in files: 
       f = f.strip()
       f = f.split('.')[0]
       a.append(f)
    
  ret = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  retroll = ret.rolling(window=400).mean()
  retroll = retroll.shift(2)
  c = ret.columns
  i = idx 
  print(ret.index[i])
  r = retroll.iloc[i, :] 
  r = r.sort_values(ascending=False)
  
  local_factor_list = list(r.index)
  select = []
  #select_df = []

  corrs = ret.iloc[i - 250:i - 2]
  corrs = corrs.corr()
  #print(corrs)
  #input()
  
  for p in range(len(local_factor_list)):
    #print('process:' + str(p))
    f = local_factor_list[p]
    #df0 = pd.read_pickle(prefix + f +'.pkl').iloc[i - 250:i+1]
    #df = pd.DataFrame(df0.values.T, index=df0.columns, columns=df0.index)
    if (len(select) == 0):
      select.append(f)
      #select_df.append(df)
    else:
      isbad = 0
      for j in range(len(select)):
        f1 = select[j]
        mc = corrs[f1].loc[f]
        if (mc > 0.85):
          isbad = 1
          break
      if (isbad == 1):
        #print('skip')
        continue
      select.append(f)
      #select_df.append(df)
      
    #if (len(select) > 5):
    #  break
  #print(select)
  
  res = pd.DataFrame({'factor':select})
  s = str(ret.index[i])[0:10]
  of = output + '/' + s + '.csv' 
  res.to_csv(of)
        
    


    



if __name__=="__main__":
    args = argparse.ArgumentParser(description = 'dftotrain',epilog = 'Information end ')
    args.add_argument("--input", type=str, dest='input', default='/data/group/800020/AlphaExperiment/neutral_factor_grow/', help = "input csv")
    args.add_argument("--output", type=str, dest='output', default='FACTORLIST', help = "output pdf")
    args.add_argument("--type", type=str, dest='type', default='490', help = "")

    args = args.parse_args()#返回一个命名空间,如果想要使用变量,可用args.attr
    d = args.__dict__
    ifile = d['input'] 
    ofile = d['output'] 
    tp = d['type'] 
    base = os.path.basename(ifile).split('.')[0]
    
    
    #sig_csv = pd.read_csv(ifile, index_col=0, low_memory=False).apply(pd.to_numeric, errors='coerce')
    #sig_csv = pd.read_pickle(ifile)

    fs = factorlist(d['input'], d['output'], int(tp))
    
    
