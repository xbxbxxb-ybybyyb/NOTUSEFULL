import pandas as pd
import argparse
import sys
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from operator import itemgetter
import matplotlib.backends.backend_pdf

import matplotlib.ticker as ticker
matplotlib.rcParams['font.family'] = 'SimHei'



#s = [10, 20, 40, 60, 80]
#tp = [1, 2, 3, 4, 5, 6]
#
#algo = ['XgboostRegression', 'LinearRegression']
#s = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
#algo = ['XgboostRegression']

res = []

instruction=['excess_ori_lookback100' ,'excess_ori_lookback200' ,'excess_ori_lookback300' ,'excess_ori_lookback400' ,'excess_ori_lookback500' ,'excess_ori_lookback600' ,'size_neu_excess_lookback100' ,'size_neu_excess_lookback200' ,'size_neu_excess_lookback300' ,'size_neu_excess_lookback400' ,'size_neu_excess_lookback500' ,'size_neu_excess_lookback600' ,'size_neu_excess_lookback100(median)' ,'size_neu_excess_lookback200(median)' ,'size_neu_excess_lookback300(median)' ,'size_neu_excess_lookback400(median)' ,'size_neu_excess_lookback500(median)' ,'size_neu_excess_lookback600(median)' ,'size_neu_excess_mean(lookback100,lookback400)' ,'size_neu_excess_mean(lookback200,lookback400)' ,'size_neu_excess_mean(lookback300,lookback400)' ,'size_neu_excess_mean(lookback400,lookback400)' ,'size_neu_excess_mean(lookback500,lookback400)' ,'size_neu_excess_mean(lookback600,lookback400)' ,'size_neu_excess_winratio_lookback100' ,'size_neu_excess_winratio_lookback200' ,'size_neu_excess_winratio_lookback300' ,'size_neu_excess_winratio_lookback400' ,'size_neu_excess_winratio_lookback500' ,'size_neu_excess_winratio_lookback600' ,'ic_ori_1d_lookback100' ,'ic_ori_1d_lookback200' ,'ic_ori_1d_lookback300' ,'ic_ori_1d_lookback400' ,'ic_ori_1d_lookback500' ,'ic_ori_1d_lookback600' ,'ic_neu_1d_lookback100' ,'ic_neu_1d_lookback200' ,'ic_neu_1d_lookback300' ,'ic_neu_1d_lookback400' ,'ic_neu_1d_lookback500' ,'ic_neu_1d_lookback600' ,'ic_ori_5d_lookback100' ,'ic_ori_5d_lookback200' ,'ic_ori_5d_lookback300' ,'ic_ori_5d_lookback400' ,'ic_ori_5d_lookback500' ,'ic_ori_5d_lookback600' ,'ic_neu_5d_lookback100' ,'ic_neu_5d_lookback200' ,'ic_neu_5d_lookback300' ,'ic_neu_5d_lookback400' ,'ic_neu_5d_lookback500' ,'ic_neu_5d_lookback600' ,'ic_ori_1d_lookback100(mean/std)' ,'ic_ori_1d_lookback200(mean/std)' ,'ic_ori_1d_lookback300(mean/std)' ,'ic_ori_1d_lookback400(mean/std)' ,'ic_ori_1d_lookback500(mean/std)' ,'ic_ori_1d_lookback600(mean/std)' ,'ic_neu_1d_lookback100(mean/std)' ,'ic_neu_1d_lookback200(mean/std)' ,'ic_neu_1d_lookback300(mean/std)' ,'ic_neu_1d_lookback400(mean/std)' ,'ic_neu_1d_lookback500(mean/std)' ,'ic_neu_1d_lookback600(mean/std)' ,'ic_ori_5d_lookback100(mean/std)' ,'ic_ori_5d_lookback200(mean/std)' ,'ic_ori_5d_lookback300(mean/std)' ,'ic_ori_5d_lookback400(mean/std)' ,'ic_ori_5d_lookback500(mean/std)' ,'ic_ori_5d_lookback600(mean/std)' ,'ic_neu_5d_lookback100(mean/std)' ,'ic_neu_5d_lookback200(mean/std)' ,'ic_neu_5d_lookback300(mean/std)' ,'ic_neu_5d_lookback400(mean/std)' ,'ic_neu_5d_lookback500(mean/std)' ,'ic_neu_5d_lookback600(mean/std)' ,'drawdown_lookback100' ,'drawdown_lookback200' ,'drawdown_lookback300' ,'drawdown_lookback400' ,'drawdown_lookback500' ,'drawdown_lookback600' ,'number_of_days_not_reach_a_new_high_lookback100' ,'number_of_days_not_reach_a_new_high_lookback200' ,'number_of_days_not_reach_a_new_high_lookback300' ,'number_of_days_not_reach_a_new_high_lookback400' ,'number_of_days_not_reach_a_new_high_lookback500' ,'number_of_days_not_reach_a_new_high_lookback600' ,'neu_excess_weighted_by_drawdown_lookback100' ,'neu_excess_weighted_by_drawdown_lookback200' ,'neu_excess_weighted_by_drawdown_lookback300' ,'neu_excess_weighted_by_drawdown_lookback400' ,'neu_excess_weighted_by_drawdown_lookback500' ,'neu_excess_weighted_by_drawdown_lookback600' ,'neu_excess_weighted_by_number_of_days_not_reach_a_new_high_lookback100' ,'neu_excess_weighted_by_number_of_days_not_reach_a_new_high_lookback200' ,'neu_excess_weighted_by_number_of_days_not_reach_a_new_high_lookback300' ,'neu_excess_weighted_by_number_of_days_not_reach_a_new_high_lookback400' ,'neu_excess_weighted_by_number_of_days_not_reach_a_new_high_lookback500' ,'neu_excess_weighted_by_number_of_days_not_reach_a_new_high_lookback600' ,'decay_lookback100' ,'decay_lookback200' ,'decay_lookback300' ,'decay_lookback400' ,'decay_lookback500' ,'decay_lookback600', 'std of skewness', 'std of kurt','icir_neu_1d_2year' ,'icir_neu_1d_3month' ,'icir_neu_5d_2year' ,'icir_neu_5d_3month' ,'icir_ori_1d_2year' ,'icir_ori_1d_3month' ,'icir_ori_5d_2year' ,'icir_ori_5d_3month' ,'ret1d_neu_1year' ,'ret1d_neu_2year' ,'ret1d_neu_3month' ,'ret1d_neu_6month' ,'ret1d_neu_decay_1y2y' ,'ret1d_neu_decay_3m1y' ,'ret1d_neu_decay_3m2y' ,'ret1d_neu_decay_6m1y' ,'ret1d_neu_decay_6m2y' ,'ret1d_neu_decay_per_1y2y' ,'ret1d_neu_decay_per_3m1y' ,'ret1d_neu_decay_per_3m2y' ,'ret1d_neu_decay_per_6m1y' ,'ret1d_neu_decay_per_6m2y' ,'ret1d_ori_1year' ,'ret1d_ori_2year' ,'ret1d_ori_3month' ,'ret1d_ori_6month' ,'ret1d_ori_decay_1y2y' ,'ret1d_ori_decay_3m1y' ,'ret1d_ori_decay_3m2y' ,'ret1d_ori_decay_6m1y' ,'ret1d_ori_decay_6m2y' ,'ret1d_ori_decay_per_1y2y' ,'ret1d_ori_decay_per_3m1y' ,'ret1d_ori_decay_per_3m2y' ,'ret1d_ori_decay_per_6m1y' ,'ret1d_ori_decay_per_6m2y' ,'ret5d_ori_1year' ,'ret5d_ori_2year' ,'ret5d_ori_3month' ,'ret5d_ori_6month' ,'ret5d_ori_decay_1y2y' ,'ret5d_ori_decay_3m1y' ,'ret5d_ori_decay_3m2y' ,'ret5d_ori_decay_6m1y' ,'ret5d_ori_decay_6m2y' ,'ret5d_ori_decay_per_1y2y' ,'ret5d_ori_decay_per_3m1y' ,'ret5d_ori_decay_per_3m2y' ,'ret5d_ori_decay_per_6m1y' ,'ret5d_ori_decay_per_6m2y' ,'sr1d_neu_1year' ,'sr1d_neu_3month' ,'sr1d_neu_6month' ,'sr1d_ori_1year' ,'sr1d_ori_3month' ,'sr1d_ori_6month' ,'sr5d_ori_1year' ,'sr5d_ori_3month' ,'sr1d_ori_1year']



start_date = '20180101'
end_date = '20201231'

fs = ['sr1d_ori_1year','sr5d_ori_1year','sr1d_neu_1year','icir_ori_1d_3month','icir_neu_1d_3month','icir_ori_5d_3month','icir_neu_5d_3month','icir_ori_1d_6month','icir_neu_1d_6month','icir_ori_5d_6month','icir_neu_5d_6month','icir_ori_1d_1year','icir_neu_1d_1year','icir_ori_5d_1year','icir_neu_5d_1year','ret1d_ori_decay_per_6m1y','ret5d_ori_decay_per_6m1y','ret1d_ori_decay_per_6m2y','ret5d_ori_decay_per_6m2y','ret1d_ori_decay_per_3m2y','ret5d_ori_decay_per_3m2y','ret5d_ori_decay_per_3m2y','sr5d_ori_6month','sr1d_ori_6month','sr1d_ori_3month','sr1d_neu_6month','sr5d_ori_3month','sr1d_neu_3month','sr1d_ori_1year_icir_ori_1d_3month']


fs=['icir_neu_1d_1year','icir_neu_1d_1year_icir_neu_1d_3month','icir_neu_1d_1year_icir_neu_1d_6month','icir_neu_1d_1year_icir_neu_5d_3month','icir_neu_1d_1year_icir_neu_5d_6month','icir_neu_1d_1year_icir_ori_1d_1year','icir_neu_1d_1year_icir_ori_1d_3month','icir_neu_1d_1year_icir_ori_1d_6month','icir_neu_1d_1year_icir_ori_5d_3month','icir_neu_1d_1year_icir_ori_5d_6month','icir_neu_1d_1year_sr1d_neu_1year','icir_neu_1d_1year_sr1d_ori_1year','icir_neu_1d_1year_sr5d_ori_1year','icir_neu_1d_3month','icir_neu_1d_3month_icir_ori_1d_3month','icir_neu_1d_3month_sr1d_neu_1year','icir_neu_1d_3month_sr1d_ori_1year','icir_neu_1d_3month_sr5d_ori_1year','icir_neu_1d_6month','icir_neu_1d_6month_icir_neu_1d_3month','icir_neu_1d_6month_icir_neu_5d_3month','icir_neu_1d_6month_icir_ori_1d_3month','icir_neu_1d_6month_icir_ori_1d_6month','icir_neu_1d_6month_icir_ori_5d_3month','icir_neu_1d_6month_sr1d_neu_1year','icir_neu_1d_6month_sr1d_ori_1year','icir_neu_1d_6month_sr5d_ori_1year','icir_neu_5d_1year','icir_neu_5d_1year_icir_neu_1d_1year','icir_neu_5d_1year_icir_neu_1d_3month','icir_neu_5d_1year_icir_neu_1d_6month','icir_neu_5d_1year_icir_neu_5d_3month','icir_neu_5d_1year_icir_neu_5d_6month','icir_neu_5d_1year_icir_ori_1d_1year','icir_neu_5d_1year_icir_ori_1d_3month','icir_neu_5d_1year_icir_ori_1d_6month','icir_neu_5d_1year_icir_ori_5d_1year','icir_neu_5d_1year_icir_ori_5d_3month','icir_neu_5d_1year_icir_ori_5d_6month','icir_neu_5d_1year_sr1d_neu_1year','icir_neu_5d_1year_sr1d_ori_1year','icir_neu_5d_1year_sr5d_ori_1year','icir_neu_5d_3month','icir_neu_5d_3month_icir_neu_1d_3month','icir_neu_5d_3month_icir_ori_1d_3month','icir_neu_5d_3month_icir_ori_5d_3month','icir_neu_5d_3month_sr1d_neu_1year','icir_neu_5d_3month_sr1d_ori_1year','icir_neu_5d_3month_sr5d_ori_1year','icir_neu_5d_6month','icir_neu_5d_6month_icir_neu_1d_3month','icir_neu_5d_6month_icir_neu_1d_6month','icir_neu_5d_6month_icir_neu_5d_3month','icir_neu_5d_6month_icir_ori_1d_3month','icir_neu_5d_6month_icir_ori_1d_6month','icir_neu_5d_6month_icir_ori_5d_3month','icir_neu_5d_6month_icir_ori_5d_6month','icir_neu_5d_6month_sr1d_neu_1year','icir_neu_5d_6month_sr1d_ori_1year','icir_neu_5d_6month_sr5d_ori_1year','icir_ori_1d_1year','icir_ori_1d_1year_icir_neu_1d_3month','icir_ori_1d_1year_icir_neu_1d_6month','icir_ori_1d_1year_icir_neu_5d_3month','icir_ori_1d_1year_icir_neu_5d_6month','icir_ori_1d_1year_icir_ori_1d_3month','icir_ori_1d_1year_icir_ori_1d_6month','icir_ori_1d_1year_icir_ori_5d_3month','icir_ori_1d_1year_icir_ori_5d_6month','icir_ori_1d_1year_sr1d_neu_1year','icir_ori_1d_1year_sr1d_ori_1year','icir_ori_1d_1year_sr5d_ori_1year','icir_ori_1d_3month','icir_ori_1d_3month_sr1d_neu_1year','icir_ori_1d_3month_sr1d_ori_1year','icir_ori_1d_3month_sr5d_ori_1year','icir_ori_1d_6month','icir_ori_1d_6month_icir_neu_1d_3month','icir_ori_1d_6month_icir_neu_5d_3month','icir_ori_1d_6month_icir_ori_1d_3month','icir_ori_1d_6month_icir_ori_5d_3month','icir_ori_1d_6month_sr1d_neu_1year','icir_ori_1d_6month_sr1d_ori_1year','icir_ori_1d_6month_sr5d_ori_1year','icir_ori_5d_1year','icir_ori_5d_1year_icir_neu_1d_1year','icir_ori_5d_1year_icir_neu_1d_3month','icir_ori_5d_1year_icir_neu_1d_6month','icir_ori_5d_1year_icir_neu_5d_3month','icir_ori_5d_1year_icir_neu_5d_6month','icir_ori_5d_1year_icir_ori_1d_1year','icir_ori_5d_1year_icir_ori_1d_3month','icir_ori_5d_1year_icir_ori_1d_6month','icir_ori_5d_1year_icir_ori_5d_3month','icir_ori_5d_1year_icir_ori_5d_6month','icir_ori_5d_1year_sr1d_neu_1year','icir_ori_5d_1year_sr1d_ori_1year','icir_ori_5d_1year_sr5d_ori_1year','icir_ori_5d_3month','icir_ori_5d_3month_icir_neu_1d_3month','icir_ori_5d_3month_icir_ori_1d_3month','icir_ori_5d_3month_sr1d_neu_1year','icir_ori_5d_3month_sr1d_ori_1year','icir_ori_5d_3month_sr5d_ori_1year','icir_ori_5d_6month','icir_ori_5d_6month_icir_neu_1d_3month','icir_ori_5d_6month_icir_neu_1d_6month','icir_ori_5d_6month_icir_neu_5d_3month','icir_ori_5d_6month_icir_ori_1d_3month','icir_ori_5d_6month_icir_ori_1d_6month','icir_ori_5d_6month_icir_ori_5d_3month','icir_ori_5d_6month_sr1d_neu_1year','icir_ori_5d_6month_sr1d_ori_1year','icir_ori_5d_6month_sr5d_ori_1year','ret1d_ori_decay_per_3m2y','ret1d_ori_decay_per_3m2y_icir_neu_1d_1year','ret1d_ori_decay_per_3m2y_icir_neu_1d_3month','ret1d_ori_decay_per_3m2y_icir_neu_1d_6month','ret1d_ori_decay_per_3m2y_icir_neu_5d_1year','ret1d_ori_decay_per_3m2y_icir_neu_5d_3month','ret1d_ori_decay_per_3m2y_icir_neu_5d_6month','ret1d_ori_decay_per_3m2y_icir_ori_1d_1year','ret1d_ori_decay_per_3m2y_icir_ori_1d_3month','ret1d_ori_decay_per_3m2y_icir_ori_1d_6month','ret1d_ori_decay_per_3m2y_icir_ori_5d_1year','ret1d_ori_decay_per_3m2y_icir_ori_5d_3month','ret1d_ori_decay_per_3m2y_icir_ori_5d_6month','ret1d_ori_decay_per_3m2y_ret1d_ori_decay_per_6m1y','ret1d_ori_decay_per_3m2y_ret1d_ori_decay_per_6m2y','ret1d_ori_decay_per_3m2y_ret5d_ori_decay_per_6m1y','ret1d_ori_decay_per_3m2y_ret5d_ori_decay_per_6m2y','ret1d_ori_decay_per_3m2y_sr1d_neu_1year','ret1d_ori_decay_per_3m2y_sr1d_ori_1year','ret1d_ori_decay_per_3m2y_sr5d_ori_1year','ret1d_ori_decay_per_6m1y','ret1d_ori_decay_per_6m1y_icir_neu_1d_1year','ret1d_ori_decay_per_6m1y_icir_neu_1d_3month','ret1d_ori_decay_per_6m1y_icir_neu_1d_6month','ret1d_ori_decay_per_6m1y_icir_neu_5d_1year','ret1d_ori_decay_per_6m1y_icir_neu_5d_3month','ret1d_ori_decay_per_6m1y_icir_neu_5d_6month','ret1d_ori_decay_per_6m1y_icir_ori_1d_1year','ret1d_ori_decay_per_6m1y_icir_ori_1d_3month','ret1d_ori_decay_per_6m1y_icir_ori_1d_6month','ret1d_ori_decay_per_6m1y_icir_ori_5d_1year','ret1d_ori_decay_per_6m1y_icir_ori_5d_3month','ret1d_ori_decay_per_6m1y_icir_ori_5d_6month','ret1d_ori_decay_per_6m1y_sr1d_neu_1year','ret1d_ori_decay_per_6m1y_sr1d_ori_1year','ret1d_ori_decay_per_6m1y_sr5d_ori_1year','ret1d_ori_decay_per_6m2y','ret1d_ori_decay_per_6m2y_icir_neu_1d_1year','ret1d_ori_decay_per_6m2y_icir_neu_1d_3month','ret1d_ori_decay_per_6m2y_icir_neu_1d_6month','ret1d_ori_decay_per_6m2y_icir_neu_5d_1year','ret1d_ori_decay_per_6m2y_icir_neu_5d_3month','ret1d_ori_decay_per_6m2y_icir_neu_5d_6month','ret1d_ori_decay_per_6m2y_icir_ori_1d_1year','ret1d_ori_decay_per_6m2y_icir_ori_1d_3month','ret1d_ori_decay_per_6m2y_icir_ori_1d_6month','ret1d_ori_decay_per_6m2y_icir_ori_5d_1year','ret1d_ori_decay_per_6m2y_icir_ori_5d_3month','ret1d_ori_decay_per_6m2y_icir_ori_5d_6month','ret1d_ori_decay_per_6m2y_ret1d_ori_decay_per_6m1y','ret1d_ori_decay_per_6m2y_ret5d_ori_decay_per_6m1y','ret1d_ori_decay_per_6m2y_sr1d_neu_1year','ret1d_ori_decay_per_6m2y_sr1d_ori_1year','ret1d_ori_decay_per_6m2y_sr5d_ori_1year','ret5d_ori_decay_per_3m2y','ret5d_ori_decay_per_3m2y_icir_neu_1d_1year','ret5d_ori_decay_per_3m2y_icir_neu_1d_3month','ret5d_ori_decay_per_3m2y_icir_neu_1d_6month','ret5d_ori_decay_per_3m2y_icir_neu_5d_1year','ret5d_ori_decay_per_3m2y_icir_neu_5d_3month','ret5d_ori_decay_per_3m2y_icir_neu_5d_6month','ret5d_ori_decay_per_3m2y_icir_ori_1d_1year','ret5d_ori_decay_per_3m2y_icir_ori_1d_3month','ret5d_ori_decay_per_3m2y_icir_ori_1d_6month','ret5d_ori_decay_per_3m2y_icir_ori_5d_1year','ret5d_ori_decay_per_3m2y_icir_ori_5d_3month','ret5d_ori_decay_per_3m2y_icir_ori_5d_6month','ret5d_ori_decay_per_3m2y_ret1d_ori_decay_per_6m1y','ret5d_ori_decay_per_3m2y_ret1d_ori_decay_per_6m2y','ret5d_ori_decay_per_3m2y_ret5d_ori_decay_per_6m1y','ret5d_ori_decay_per_3m2y_ret5d_ori_decay_per_6m2y','ret5d_ori_decay_per_3m2y_sr1d_neu_1year','ret5d_ori_decay_per_3m2y_sr1d_ori_1year','ret5d_ori_decay_per_3m2y_sr5d_ori_1year','ret5d_ori_decay_per_6m1y','ret5d_ori_decay_per_6m1y_icir_neu_1d_1year','ret5d_ori_decay_per_6m1y_icir_neu_1d_3month','ret5d_ori_decay_per_6m1y_icir_neu_1d_6month','ret5d_ori_decay_per_6m1y_icir_neu_5d_1year','ret5d_ori_decay_per_6m1y_icir_neu_5d_3month','ret5d_ori_decay_per_6m1y_icir_neu_5d_6month','ret5d_ori_decay_per_6m1y_icir_ori_1d_1year','ret5d_ori_decay_per_6m1y_icir_ori_1d_3month','ret5d_ori_decay_per_6m1y_icir_ori_1d_6month','ret5d_ori_decay_per_6m1y_icir_ori_5d_1year','ret5d_ori_decay_per_6m1y_icir_ori_5d_3month','ret5d_ori_decay_per_6m1y_icir_ori_5d_6month','ret5d_ori_decay_per_6m1y_ret1d_ori_decay_per_6m1y','ret5d_ori_decay_per_6m1y_sr1d_neu_1year','ret5d_ori_decay_per_6m1y_sr1d_ori_1year','ret5d_ori_decay_per_6m1y_sr5d_ori_1year','ret5d_ori_decay_per_6m2y','ret5d_ori_decay_per_6m2y_icir_neu_1d_1year','ret5d_ori_decay_per_6m2y_icir_neu_1d_3month','ret5d_ori_decay_per_6m2y_icir_neu_1d_6month','ret5d_ori_decay_per_6m2y_icir_neu_5d_1year','ret5d_ori_decay_per_6m2y_icir_neu_5d_3month','ret5d_ori_decay_per_6m2y_icir_neu_5d_6month','ret5d_ori_decay_per_6m2y_icir_ori_1d_1year','ret5d_ori_decay_per_6m2y_icir_ori_1d_3month','ret5d_ori_decay_per_6m2y_icir_ori_1d_6month','ret5d_ori_decay_per_6m2y_icir_ori_5d_1year','ret5d_ori_decay_per_6m2y_icir_ori_5d_3month','ret5d_ori_decay_per_6m2y_icir_ori_5d_6month','ret5d_ori_decay_per_6m2y_ret1d_ori_decay_per_6m1y','ret5d_ori_decay_per_6m2y_ret1d_ori_decay_per_6m2y','ret5d_ori_decay_per_6m2y_ret5d_ori_decay_per_6m1y','ret5d_ori_decay_per_6m2y_sr1d_neu_1year','ret5d_ori_decay_per_6m2y_sr1d_ori_1year','ret5d_ori_decay_per_6m2y_sr5d_ori_1year','sr1d_neu_1year','sr1d_neu_1year_sr1d_ori_1year','sr1d_neu_1year_sr5d_ori_1year','sr1d_neu_3month','sr1d_neu_6month','sr1d_ori_1year','sr1d_ori_1year_icir_ori_1d_3month','sr1d_ori_3month','sr1d_ori_6month','sr5d_ori_1year','sr5d_ori_1year_sr1d_ori_1year','sr5d_ori_3month','sr5d_ori_6month']
fs = ['icir_ori_1d_3month_sr1d_ori_1year', 'old']

aas = []
vs = []

for t in range(len(fs)):
  a = pd.read_csv('RES/' + fs[t] + '_res.csv', index_col=0)
  v = a['cumdiff'].iloc[-1]

  aas.append(fs[t])
  vs.append(v)

pp = pd.DataFrame({'aas':aas, 'vs':vs})
pp = pp.sort_values(by='vs', ascending=False)
#print(pp)
#input()

fs = list(pp['aas'])

for t in range(len(fs)):
  a = pd.read_csv('RES/' + fs[t] + '_res.csv', index_col=0)
  print('RES/TYPE' + fs[t] + '_res.csv')

  ix = 0
  for i in range(a.shape[0]):
    if (a.index[i] == '2018-01-04'):
      ix = i
      break
  ie = -1
  for i in range(a.shape[0]):
    if (a.index[i] == '2021-01-04'):
      ie = i
      break
  a = a.iloc[ix:ie]
  #print(a.shape)
  #input()
  #a['rel'] = a['rel'] / a['rel'].iloc[0]
  a['cumdiff'] = a['cumdiff'] - a['cumdiff'].iloc[0]
  #print(a)
  #input()


  #print(a.index)
  #print(a['cumdiff'])
  #input()
  #res.append([list(a.index), list(a['rel']), 'TYPE' + str(t)])
  res.append([list(a.index), list(a['cumdiff']), fs[t]])
  #res.append([list(a.index), list(a['rel'] / a['rel'].iloc[0]), instruction[t]])








#output = 'FACTOR_EXPERIMENT_sr1d_ori_1year_all_every90days'
output = 'STANDARD_210402902'


with matplotlib.backends.backend_pdf.PdfPages(output + '.pdf') as pdf:
    for i in range(int(len(res)/9) + 1):
        fig = plt.figure(figsize=(15, 15))
        fig.tight_layout()
        plot_num = 331
        for j in range(9 * i, 9 * (i + 1)):
            if j < len(res):
                plt.subplot(plot_num)
                #f = factor_list[j]#%excessReturn.columns[j]
                #print(f)
                #df = pd.read_pickle(prefix + f + '.pkl').loc[start_date:end_date]
                ##plt.hist(df.stack().values,bins=100)

                #r = df.shape[0]
                #df1 = df.iloc[0:r // 2, :]
                #df2 = df.iloc[r // 2:-1, :]

                #plt.hist(df1.stack().values, bins=100, alpha=0.5, label='first half')
                #plt.hist(df2.stack().values, bins=100, alpha=0.5, label='second half')
                plt.plot(res[j][0], res[j][1], '-')
                #[0, 6, 12, 36, 48], [0, 6, 12, 36, 48]
                v = res[j][0]
                plt.xticks(list(range(0,len(v), 200)), v[0:-1:200])

                #ax.xaxis.set_major_locator(ticker.MultipleLocator(base=50))
                plt.title(res[j][2])
                plt.xlabel('time')
                #plt.ylabel('cum relative to bench mark')
                plt.ylabel('cum diff')
                plot_num += 1
        plt.rcParams.update({'font.size': 8})
        pdf.savefig(fig)

    #fig = plt.figure(figsize=(15, 15))
    #x = np.linspace(0.05, 10, 1000)
    #y = np.sin(x)
    ##plt.plot(x, y, ls="-.", lw=2, c="c", label="plot figure")
    ##plt.legend()
    #plt.text(0, 0.9, "TYPE0 score = rolling 400 day's accret * (1 - rank of skewness' std for past 40 days)  [idea accret weighted by stableness of skewness]", weight="bold", color="b")
    #plt.text(0, 0.89, "TYPE1 score = rolling 400 day's accret * (1 - rank of skewness' std for past 80 days)", weight="bold", color="b")
    #plt.text(0, 0.88, "TYPE2 score = rolling 400 day's accret * (1 - rank of skewness' std for past 120 days)", weight="bold", color="b")
    #plt.text(0, 0.87, "TYPE3 score = rolling 400 day's accret * (1 - rank of skewness' std for past 240 days)", weight="bold", color="b")

    #plt.text(0, 0.86, "TYPE4 score = rolling 400 day's accret * (1 - rank of kurt' std for past 40 days)[idea accret weighted by stableness of kurt]", weight="bold", color="b")
    #plt.text(0, 0.85, "TYPE5 score = rolling 400 day's accret * (1 - rank of kurt' std for past 80 days)", weight="bold", color="b")
    #plt.text(0, 0.84, "TYPE6 score = rolling 400 day's accret * (1 - rank of kurt' std for past 120 days)", weight="bold", color="b")
    #plt.text(0, 0.83, "TYPE7 score = rolling 400 day's accret * (1 - rank of kurt' std for past 240 days)", weight="bold", color="b")

    #plt.text(0, 0.82, "TYPE8 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 40 days) [idea accret weighted by each stock's mean value]", weight="bold", color="b")
    #plt.text(0, 0.81, "TYPE9 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 80 days)", weight="bold", color="b")
    #plt.text(0, 0.80, "TYPE10 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 120 days)", weight="bold", color="b")
    #plt.text(0, 0.79, "TYPE11 score = rolling 400 day's accret * (1 - rank of std of each factor's mean value (by stock) for past 240 days)", weight="bold", color="b")

    #plt.text(0, 0.78, "TYPE12 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 40 days) [idea accret weighted by each stock's std's]", weight="bold", color="b")
    #plt.text(0, 0.77, "TYPE13 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 80 days)", weight="bold", color="b")
    #plt.text(0, 0.76, "TYPE14 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 120 days)", weight="bold", color="b")
    #plt.text(0, 0.75, "TYPE15 score = rolling 400 day's accret * (1 - rank of std of each factor's std value (by stock) for past 240 days)", weight="bold", color="b")

    #plt.text(0, 0.74, "TYPE16 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 40 days) [idea accret weighted by each stock's std(similar as previous)]", weight="bold", color="b")
    #plt.text(0, 0.73, "TYPE17 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 80 days)", weight="bold", color="b")
    #plt.text(0, 0.72, "TYPE18 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 120 days)", weight="bold", color="b")
    #plt.text(0, 0.71, "TYPE19 score = rolling 400 day's accret * (1 - rank of mean of each factor's std value (by stock) for past 240 days)", weight="bold", color="b")

    #plt.text(0, 0.70, "BENCHMARK is using rolling 400 day's accret, rank the factor and pick the top 1000 factors, then calculate BASELINE = next 30day's average ret")
    #plt.text(0, 0.69, "COMPARISON is using new score, rank the factor and pick the top 1000 factors, then calculate COMPARISON=next 30day's average ret")
    #plt.text(0, 0.68, "each plot is COMPARISON / BASELINE - 1's cumsum")
    #plt.text(0, 0.57, "TYPE20-29 min(kday ret, 400day ret) k = 40 60 ..220 ")
    #plt.text(0, 0.56, "TYPE30-39 mean(kday ret, 400day ret) k = 40 60 ..220 ")
    #plt.text(0, 0.55, "TYPE40-49 mean(k day ret) / std(k day ret) k = 50 100 ..500 ")
    #plt.text(0, 0.54, "TYPE50-59 median(k day ret) / std(k day ret) k = 50 100 ..500 ")
    #

    #pdf.savefig(fig)
  
#f = open(output + '.csv', 'w')
#for i in range(len(factor_list)):
#  f.write(str(factor_score[i]) + ',' + factor_list[i] + '\n')
#f.close()

        
  
