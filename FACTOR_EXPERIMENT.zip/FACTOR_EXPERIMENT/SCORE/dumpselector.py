import argparse
import sys
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from operator import itemgetter
import matplotlib.backends.backend_pdf


# In[14]:
start_date = '20160101'
end_date = '20201231'

def LoadScore(df, tp):
  if (tp == 'TYPE0'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=40, min_periods=1).std()
    return sk
  elif (tp == 'TYPE1'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=80, min_periods=1).std()
    return sk
  elif (tp == 'TYPE2'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=120, min_periods=1).std()
    return sk
  elif (tp == 'TYPE3'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=240, min_periods=1).std()
    return sk
  elif (tp == 'TYPE4'):
    sz = df.shape[0]
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=40, min_periods=1).std()
    return sk
  elif (tp == 'TYPE5'):
    sz = df.shape[0]
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=80, min_periods=1).std()
    return sk
  elif (tp == 'TYPE6'):
    sz = df.shape[0]
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=120, min_periods=1).std()
    return sk
  elif (tp == 'TYPE7'):
    sz = df.shape[0]
    v = [0] * sz
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=240, min_periods=1).std()
    return sk
  elif (tp == 'TYPE8'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 40 < 0):continue
      s = df.iloc[i - 40:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE9'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 80 < 0):continue
      s = df.iloc[i - 80:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE10'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 120 < 0):continue
      s = df.iloc[i - 120:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE11'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 240 < 0):continue
      s = df.iloc[i - 240:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE12'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 40 < 0):continue
      s = df.iloc[i - 40:i + 1, :]
      v[i] = s.std(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE13'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 80 < 0):continue
      s = df.iloc[i - 80:i + 1, :]
      v[i] = s.std(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE14'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 120 < 0):continue
      s = df.iloc[i - 120:i + 1, :]
      v[i] = s.std(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE15'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 240 < 0):continue
      s = df.iloc[i - 240:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  
  elif (tp == 'TYPE16'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 40 < 0):continue
      s = df.iloc[i - 40:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE17'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 80 < 0):continue
      s = df.iloc[i - 80:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE18'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 120 < 0):continue
      s = df.iloc[i - 120:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE19'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 240 < 0):continue
      s = df.iloc[i - 240:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp





def LoadCol():
  a = pd.read('factor_depart_size_neu_excess.pkl')
  return a.columns


def T0(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['excess_ori_1d']
  a = a.rolling(window=bd).mean()
  return a.shift(3)
  #a = pd.read_pickle('ret_dict.pkl')
  #a = a['ret1d_ori_1year']
  #return a

def T1(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  a = a.rolling(window=bd).mean()
  return a.shift(3)

def T2(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  a = a.rolling(window=bd).median()
  return a.shift(3)

def T3(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  a1 = a.rolling(window=400).mean()
  a2 = a.rolling(window=bd).mean()
  a = (a1 + a2) / 2
  return a.shift(3)
  
def T4(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  a = a.rolling(window=bd).apply(lambda x:np.sum(x>0)/bd)
  return a.shift(3)


def T5(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_ori_1d']
  a = a.rolling(window=bd).mean()
  return a.shift(3)

def T6(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_neu_1d']
  a = a.rolling(window=bd).mean()
  return a.shift(3)

def T7(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_ori_5d']
  a = a.rolling(window=bd).mean()
  return a.shift(6)

def T8(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_neu_5d']
  a = a.rolling(window=bd).mean()
  return a.shift(6)


def T9(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_ori_1d']
  a = a.rolling(window=bd).mean() / a.rolling(window=bd).std()
  return a.shift(3)

def T10(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_neu_1d']
  a = a.rolling(window=bd).mean() / a.rolling(window=bd).std()
  return a.shift(3)

def T11(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_ori_5d']
  a = a.rolling(window=bd).mean() / a.rolling(window=bd).std()
  return a.shift(6)

def T12(bd):
  a = pd.read_pickle('factor_perform_multi_index.pkl')
  a = a['ic_neu_5d']
  a = a.rolling(window=bd).mean() / a.rolling(window=bd).std()
  return a.shift(6)


def DD(x):
  cum = 0
  maxv = 0
  maxdd = 0
  for i in x:
    if (np.isnan(i) == True):continue
    cum = cum + i
    if (cum > maxv):
      maxv = cum
    dd = maxv - cum
    if (dd > maxdd):
      maxdd = dd
  return maxdd
    
def DDT(x):
  cum = 0
  maxv = 0
  maxdd = 0
  cnt = 0
  for i in x:
    if (np.isnan(i) == True):continue
    cum = cum + i
    if (cum > maxv):
      maxv = cum
      cnt = 0
      continue
    dd = maxv - cum
    if (dd > maxdd):
      maxdd = dd
    if (maxv > cum):
      cnt = cnt + 1
  return cnt / len(x)
    

def T13(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  a = a.rolling(window=bd).apply(lambda x:-DD(x))
  return a.shift(3)

def T14(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  a = a.rolling(window=bd).apply(lambda x:-DDT(x))
  return a.shift(3)
  
def T15(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  b = a.rolling(window=bd).apply(lambda x:DD(x))
  a = a.rolling(window=bd).mean()
  a = a / (2 * b + 1)
  return a.shift(3)

def T16(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  b = a.rolling(window=bd).apply(lambda x:DDT(x))
  a = a.rolling(window=bd).mean()
  a = a / (b + 1)
  return a.shift(3)

def T17(bd):
  a = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  a = a.rolling(window=bd).apply(lambda x:np.sum(x>0)/bd)
  a1 = a.rolling(window=bd//2).apply(lambda x:np.sum(x>0)/bd)
  for i in range(a.shape[0]):
    for j in range(a.shape[1]):
      if (a.iloc[i, j] > a1.iloc[i, j]):
        a.iloc[i, j] = a1.iloc[i, j]
  return a.shift(3)



def LoadFactorScore(prefix, output, tp):
    
    #raw ret
    if (tp == 0):return T0(250)
    if (tp == 1):return T0(200)
    if (tp == 2):return T0(300)
    if (tp == 3):return T0(400)
    if (tp == 4):return T0(500)
    if (tp == 5):return T0(600)

    #1adj ret 
    if (tp == 6):return T1(100)
    if (tp == 7):return T1(200)
    if (tp == 8):return T1(300)
    if (tp == 9):return T1(400)
    if (tp == 10):return T1(500)
    if (tp == 11):return T1(600)
      
    #2adj ret median
    if (tp == 12):return T2(100)
    if (tp == 13):return T2(200)
    if (tp == 14):return T2(300)
    if (tp == 15):return T2(400)
    if (tp == 16):return T2(500)
    if (tp == 17):return T2(600)

    #3adj ret ewm
    if (tp == 18):return T3(40)
    if (tp == 19):return T3(80)
    if (tp == 20):return T3(120)
    if (tp == 21):return T3(160)
    if (tp == 22):return T3(200)
    if (tp == 23):return T3(240)
      
    #3adj ret 
    if (tp == 24):return T4(100)
    if (tp == 25):return T4(200)
    if (tp == 26):return T4(300)
    if (tp == 27):return T4(400)
    if (tp == 28):return T4(500)
    if (tp == 29):return T4(600)

    if (tp == 30):return T5(100)
    if (tp == 31):return T5(200)
    if (tp == 32):return T5(300)
    if (tp == 33):return T5(400)
    if (tp == 34):return T5(500)
    if (tp == 35):return T5(600)
      

    if (tp == 36):return T6(100)
    if (tp == 37):return T6(200)
    if (tp == 38):return T6(300)
    if (tp == 39):return T6(400)
    if (tp == 40):return T6(500)
    if (tp == 41):return T6(600)

    if (tp == 42):return T7(100)
    if (tp == 43):return T7(200)
    if (tp == 44):return T7(300)
    if (tp == 45):return T7(400)
    if (tp == 46):return T7(500)
    if (tp == 47):return T7(600)

    if (tp == 48):return T8(100)
    if (tp == 49):return T8(200)
    if (tp == 50):return T8(300)
    if (tp == 51):return T8(400)
    if (tp == 52):return T8(500)
    if (tp == 53):return T8(600)

    if (tp == 54):return T9(100)
    if (tp == 55):return T9(200)
    if (tp == 56):return T9(300)
    if (tp == 57):return T9(400)
    if (tp == 58):return T9(500)
    if (tp == 59):return T9(600)

    if (tp == 60):return T10(100)
    if (tp == 61):return T10(200)
    if (tp == 62):return T10(300)
    if (tp == 63):return T10(400)
    if (tp == 64):return T10(500)
    if (tp == 65):return T10(600)

    if (tp == 66):return T11(100)
    if (tp == 67):return T11(200)
    if (tp == 68):return T11(300)
    if (tp == 69):return T11(400)
    if (tp == 70):return T11(500)
    if (tp == 71):return T11(600)

    if (tp == 72):return T12(100)
    if (tp == 73):return T12(200)
    if (tp == 74):return T12(300)
    if (tp == 75):return T12(400)
    if (tp == 76):return T12(500)
    if (tp == 77):return T12(600)

    if (tp == 78):return T13(100)
    if (tp == 79):return T13(200)
    if (tp == 80):return T13(300)
    if (tp == 81):return T13(400)
    if (tp == 82):return T13(500)
    if (tp == 83):return T13(600)

    if (tp == 84):return T14(100)
    if (tp == 85):return T14(200)
    if (tp == 86):return T14(300)
    if (tp == 87):return T14(400)
    if (tp == 88):return T14(500)
    if (tp == 89):return T14(600)

    if (tp == 90):return T15(100)
    if (tp == 91):return T15(200)
    if (tp == 92):return T15(300)
    if (tp == 93):return T15(400)
    if (tp == 94):return T15(500)
    if (tp == 95):return T15(600)

    if (tp == 96):return T16(100)
    if (tp == 97):return T16(200)
    if (tp == 98):return T16(300)
    if (tp == 99):return T16(400)
    if (tp == 100):return T16(500)
    if (tp == 101):return T16(600)

    if (tp == 102):return T17(100)
    if (tp == 103):return T17(200)
    if (tp == 104):return T17(300)
    if (tp == 105):return T17(400)
    if (tp == 106):return T17(500)
    if (tp == 107):return T17(600)
    #res = pd.DataFrame()
    #for root,dirs,files in 6s.walk(prefix): 
    #   #for dir in dirs: 
    #   #    print os.path.join(root,dir).decode('gbk').encode('utf-8'); 
    #   for f in files: 
    #     print(f)
    #     f = f.strip()
    #     f = f.split('.')[0]
    #     #print os.path.join(root,file).decode('gbk').encode('utf-8');
    #     df = pd.read_pickle(prefix + f +'.pkl').loc[start_date:end_date]

    #     local_score = LoadScore(df, tp)
    #     res[f] = local_score

    #
    ##print(res)
    #res.to_csv(output)





  

def LoadFactorScore1(prefix, output, tp):
    
    res = pd.DataFrame()
    for root,dirs,files in os.walk(prefix): 
       #for dir in dirs: 
       #    print os.path.join(root,dir).decode('gbk').encode('utf-8'); 
       for f in files: 
         print(f)
         f = f.strip()
         f = f.split('.')[0]
         #print os.path.join(root,file).decode('gbk').encode('utf-8');
         df = pd.read_pickle(prefix + f +'.pkl').loc[start_date:end_date]

         local_score = LoadScore(df, tp)
         res[f] = local_score
         #if (res.shape[1] > 5):
         #  break
         #res.append([local_score, f])
         #if (len(res) > 20):
         #  break
         #input()

    
    #print(res)
    res.to_csv(output)
    
    


    



if __name__=="__main__":
    args = argparse.ArgumentParser(description = 'dftotrain',epilog = 'Information end ')
    args.add_argument("--input", type=str, dest='input', default='/data/group/800020/AlphaExperiment/neutral_factor_grow/', help = "input csv")
    args.add_argument("--output", type=str, dest='output', default='/data/user/012316/output', help = "output pdf")



    args.add_argument("--return", type=str, dest='return', default='/home/yzhan/CPP/exprgen/DUMPCSV/DATA/ret', help = "target csv")
    args.add_argument("--cap", type=str, dest='cap', default='/home/yzhan/CPP/exprgen/DUMPCSV/DATA/cap', help = "cap csv")


    args.add_argument("--type", type=str, dest='type', default='raw', help = "")

    args = args.parse_args()#返回一个命名空间,如果想要使用变量,可用args.attr
    d = args.__dict__
    ifile = d['input'] 
    ofile = d['output'] 
    ret = d['return'] 
    cap = d['cap'] 
    tp = d['type'] 
    base = os.path.basename(ifile).split('.')[0]
    
    
    #sig_csv = pd.read_csv(ifile, index_col=0, low_memory=False).apply(pd.to_numeric, errors='coerce')
    #sig_csv = pd.read_pickle(ifile)

    
    res = LoadFactorScore(d['input'], d['output'], int(d['type']))
    #res = LoadFactorScore(d['input'], d['output'], 18)
    #print(res)
    #input()
    res.to_csv(d['output'])
    
