import pandas as pd
import numpy as np

#ret=pd.read_pickle('factor_depart_size_neu_excess.pkl')

ret = pd.read_pickle('factor_perform_multi_index.pkl')
ret = ret['excess_ori_1d']

import sys

f = sys.argv[1]
sc = pd.read_csv('OUTPUT/' + f + '.csv', index_col=0)
sc.index = pd.DatetimeIndex(sc.index)

col1 = set(ret.columns)
col2 = set(sc.columns)
#print(len(col1))
#print(len(col2))
#cin.get()
col = list(col1 & col2)
ret = ret[col]
sc= sc[col]
#sc = sc.rank(axis=1) / sc.shape[1]

retroll = ret.rolling(window=400).mean()
retroll = retroll.shift(3)

#sc = sc.rolling(window=100, min_periods=1).mean()

retroll = retroll.loc[sc.index]
ret = ret.loc[sc.index]
#print(retroll)
#input()
#print(sc)
#input()
#print(ret)
#input()


#res = pd.DataFrame()
#res.index = retroll.index
#print(res)
#input()



idx = []
v0 = []
v1 = []


for i in range(retroll.shape[0] - 40):
  r = retroll.iloc[i, :] 
  r = r.sort_values(ascending=False)
  #print(r)
  #input()
  s = i
  e = i + 6
  good = r.index[0:1300]
  local = ret
  local = local.iloc[s:e]
  #print(local)
  #input()
  m0 = np.mean(local.mean())
  v0.append(m0)
  
  #print(retroll.iloc[i, :])
  #print(1 - sc.iloc[i, :] * 0.1)
  #input()
  r = sc.iloc[i, :]#retroll.iloc[i, :]  * (1 - (sc.iloc[i, :]) * 0.1)
  r = r.sort_values(ascending=False)
  #print(r)
  #input()
  s = i
  e = i + 6
  good = r.index[0:1300]
  local = ret[good]
  local = local.iloc[s:e]
  #print(local)
  #input()
  m1 = np.mean(local.mean())
  v1.append(m1)
  idx.append(retroll.index[i])
  
  
  
  
  




res = pd.DataFrame({'bench':v0, 'adj':v1}, index=idx)
res['benchcum'] = res['bench'].cumsum()
res['adjcum'] = res['adj'].cumsum()


res['diff'] = res['adj'] - res['bench']
res['cumdiff'] = res['diff'].cumsum()
res['rel'] = res['adjcum'] / res['benchcum']
print(res)


res.to_csv('RES/' + f + '_res.csv')
