import pandas as pd
import numpy as np
import sys


#0. excess ret
ret0=pd.read_pickle('factor_depart_size_neu_excess.pkl')
ret = pd.read_pickle('factor_perform_multi_index.pkl')
ret = ret['excess_ori_1d']
ret = ret.loc[ret0.index]


#1. 输出文件名 保存到 'RES/' + f + '_res.csv' 确保路径存在
f = sys.argv[1]




#2. idx = [date] v0=[excess ret benchmark] v1=[excess ret filtered by factor]
idx = []
v0 = []
v1 = []

#3. for each day

for i in range(490,1215):
  #4. update factor list every 90 days 
  ss = str(ret.index[i - i % 60])[0:10]
  
  #5. bench mark
  bench = pd.read_csv('FACTORLIST/' + ss + '.csv', index_col=0)
  s = i
  e = i + 1
  good = bench['factor']
  #local = ret[good]
  local = ret
  local = local.iloc[s:e]
  m0 = np.mean(local.mean())
  #6. store average return
  v0.append(m0)

  
  #7. filter by factor
  compare = pd.read_csv('FACTORLIST1/' + f + '/' + ss + '.csv', index_col=0)

  good = compare['factor']#list(set(ret0.columns) - set(localdict[ss]))
  #print('good' + str(good.shape))
  #print('out' + str(ret.shape[1] - good.shape[0]))
  local = ret[good]
  local = local.iloc[s:e]
  m1 = np.mean(local.mean())

  #8. store average return
  v1.append(m1)
  idx.append(ret.index[i])
  

  
  



#9. to csv

res = pd.DataFrame({'bench':v0, 'adj':v1}, index=idx)
res['benchcum'] = res['bench'].cumsum()
res['adjcum'] = res['adj'].cumsum()
res['diff'] = res['adj'] - res['bench']
res['rawcumdiff'] = res['diff'].cumsum()
res['cumdiff'] = res['diff'].cumsum() / res['benchcum'].iloc[-1]

res['rel'] = res['adjcum'] / res['benchcum']
print(res)


res.to_csv('RES/' + f + '_res.csv')
