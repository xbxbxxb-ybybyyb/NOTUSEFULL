#gensignal
python3 dumpselector.py --type 0
python3 torank.py TYPE0
python3 merge_result.py

