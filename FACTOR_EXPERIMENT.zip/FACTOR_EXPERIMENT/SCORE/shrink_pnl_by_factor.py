import argparse
import sys
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from operator import itemgetter
import matplotlib.backends.backend_pdf


# In[14]:
start_date = '20160101'
end_date = '20201231'




    

def factorlist(prefix, output, kk, idx):
  
    
  #0. excess ret
  ret0 = pd.read_pickle('factor_depart_size_neu_excess.pkl')

  ret = pd.read_pickle('factor_perform_multi_index.pkl')
  ret = ret['excess_ori_1d']
  ret0 = ret.loc[ret0.index]

  try:
    os.makedirs(output + '/' + kk)
  except:
    pass

  #'sr1d_ori_1year', 'sr5d_ori_1year', 'sr1d_neu_1year', 'icir_ori_1d_3month', 'icir_neu_1d_3month', 'icir_ori_5d_3month', 'icir_neu_5d_3month', 'icir_ori_1d_6month', 'icir_neu_1d_6month', 'icir_ori_5d_6month', 'icir_neu_5d_6month', 'icir_ori_1d_1year', 'icir_neu_1d_1year', 'icir_ori_5d_1year', 'icir_neu_5d_1year', 'ret1d_ori_decay_per_6m1y', 'ret5d_ori_decay_per_6m1y', 'ret1d_ori_decay_per_6m2y', 'ret5d_ori_decay_per_6m2y', 'ret1d_ori_decay_per_3m2y', 'ret5d_ori_decay_per_3m2y'


  #1. define your factor
  a = pd.read_pickle('ret_dict2.pkl')
  #print(a.keys())
  #input()
  #a = a['sr1d_ori_1year']
  a = a[kk]
  #a = a['ret1d_ori_1year']
  a = a.reindex(ret0.index)


  hvalue = a

  
  
  #2. rolling excess ret for filtering those ret < 0 stocks
  retroll = ret0.rolling(window=240).mean()
  retroll = retroll.shift(2)
  c = hvalue.columns

  #3. current day index i, pass from command line
  i = idx 
  print(hvalue.index[i])
  
  #4. sort factors by 'your factor value'
  r = hvalue.iloc[i, :] 
  r = r.sort_values(ascending=False)
  
  #5. select only 4/5 factors by 'your factor value'
  local_factor_list = list(r.index)
  local_factor_list = local_factor_list[:len(local_factor_list) * 5 // 6]
  #local_factor_list = local_factor_list[:len(local_factor_list) * 4 // 5]

  
  #5. sort factors by 'excess return', because high corr stock, we need drop those low 'excess return' one
  sa = retroll[local_factor_list]
  r = sa.iloc[i, :] 
  r = r.sort_values(ascending=False)
  local_factor_list = list(r.index)
  
    

  #6. selected factors
  select = []

  #7. precalculate corr
  #corrs = ret0.iloc[i - 250:i - 2]
  #corrs = ret0.iloc[i - 720:i - 2]
  corrs = ret0.iloc[:i - 2]
  #print(ret0.index)
  #input()
  #corrs = corrs.corr(method='spearman')
  corrs = corrs.corr()
  

  #8. start simulation
  
  for p in range(len(local_factor_list)):
    f = local_factor_list[p]
    #9. if negative ret continue
    if (retroll[f].iloc[i] < 0):
      continue

    #10. if first one just append to select
    if (len(select) == 0):
      select.append(f)
    else:
      #11. if high corr just continue
      isbad = 0
      
      maxc = np.max(corrs[f].loc[select])
      if (maxc > 0.7):
        isbad = 1
      
      #for j in range(len(select)):
      #  f1 = select[j]
      #  mc = corrs[f1].loc[f]
      #  if (mc > 0.7):
      #    isbad = 1
      #    break
      if (isbad == 1):
        #print('skip' + f)
        continue
      select.append(f)
  
  #12. store selected factor in a file name output + '/' + s + '.csv'
  res = pd.DataFrame({'factor':select})
  s = str(ret0.index[i])[0:10]
  of = output + '/' + kk + '/' + s + '.csv' 
  res.to_csv(of)
        
    


    



if __name__=="__main__":
    args = argparse.ArgumentParser(description = 'dftotrain',epilog = 'Information end ')
    args.add_argument("--input", type=str, dest='input', default='/data/group/800020/AlphaExperiment/neutral_factor_grow/', help = "input csv")
    args.add_argument("--output", type=str, dest='output', default='FACTORLIST1', help = "output pdf")
    args.add_argument("--key", type=str, dest='key', default='sr1d_ori_1year', help = "output pdf")
    args.add_argument("--type", type=str, dest='type', default='490', help = "")

    args = args.parse_args()#返回一个命名空间,如果想要使用变量,可用args.attr
    d = args.__dict__
    ifile = d['input'] 
    ofile = d['output'] 
    tp = d['type'] 
    kk = d['key'] 
    base = os.path.basename(ifile).split('.')[0]

    fs = factorlist(d['input'], d['output'], d['key'], int(tp))
    #1. --output 设成本地文件夹
    #2. --type 设成天的id可以从240到1215
    #python3 shrink_pnl_by_factor.py --type 300
    
