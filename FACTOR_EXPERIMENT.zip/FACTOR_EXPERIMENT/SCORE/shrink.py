import argparse
import sys
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from operator import itemgetter
import matplotlib.backends.backend_pdf


# In[14]:
start_date = '20160101'
end_date = '20201231'

def LoadScore(df, tp):
  if (tp == 'TYPE0'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=40, min_periods=1).std()
    return sk
  elif (tp == 'TYPE1'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=80, min_periods=1).std()
    return sk
  elif (tp == 'TYPE2'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=120, min_periods=1).std()
    return sk
  elif (tp == 'TYPE3'):
    sz = df.shape[0]
    sk = df.skew(axis=1)
    sk = sk.rolling(window=240, min_periods=1).std()
    return sk
  elif (tp == 'TYPE4'):
    sz = df.shape[0]
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=40, min_periods=1).std()
    return sk
  elif (tp == 'TYPE5'):
    sz = df.shape[0]
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=80, min_periods=1).std()
    return sk
  elif (tp == 'TYPE6'):
    sz = df.shape[0]
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=120, min_periods=1).std()
    return sk
  elif (tp == 'TYPE7'):
    sz = df.shape[0]
    v = [0] * sz
    sk = df.kurt(axis=1)
    sk = sk.rolling(window=240, min_periods=1).std()
    return sk
  elif (tp == 'TYPE8'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 40 < 0):continue
      s = df.iloc[i - 40:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE9'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 80 < 0):continue
      s = df.iloc[i - 80:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE10'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 120 < 0):continue
      s = df.iloc[i - 120:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE11'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 240 < 0):continue
      s = df.iloc[i - 240:i + 1, :]
      v[i] = s.mean(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE12'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 40 < 0):continue
      s = df.iloc[i - 40:i + 1, :]
      v[i] = s.std(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE13'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 80 < 0):continue
      s = df.iloc[i - 80:i + 1, :]
      v[i] = s.std(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE14'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 120 < 0):continue
      s = df.iloc[i - 120:i + 1, :]
      v[i] = s.std(axis=0).std()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE15'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 240 < 0):continue
      s = df.iloc[i - 240:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  
  elif (tp == 'TYPE16'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 40 < 0):continue
      s = df.iloc[i - 40:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE17'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 80 < 0):continue
      s = df.iloc[i - 80:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE18'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 120 < 0):continue
      s = df.iloc[i - 120:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp
  elif (tp == 'TYPE19'):
    sz = df.shape[0]
    v = [0] * sz
    for i in range(sz):
      if (i - 240 < 0):continue
      s = df.iloc[i - 240:i + 1, :]
      v[i] = s.std(axis=0).mean()
    tmp = pd.Series(v)
    tmp.index=df.index
    return tmp







    
  

def LoadFactorScore(prefix, output, tp):
    
    res = pd.DataFrame()
    for root,dirs,files in os.walk(prefix): 
       #for dir in dirs: 
       #    print os.path.join(root,dir).decode('gbk').encode('utf-8'); 
       for f in files: 
         print(f)
         f = f.strip()
         f = f.split('.')[0]
         #print os.path.join(root,file).decode('gbk').encode('utf-8');
         df = pd.read_pickle(prefix + f +'.pkl').loc[start_date:end_date]

         local_score = LoadScore(df, tp)
         res[f] = local_score
         #if (res.shape[1] > 5):
         #  break
         #res.append([local_score, f])
         #if (len(res) > 20):
         #  break
         #input()

    
    #print(res)
    res.to_csv(output)
    

def factorlist(prefix, output, idx):
  a = []
  for root,dirs,files in os.walk(prefix): 
     #for dir in dirs: 
     #    print os.path.join(root,dir).decode('gbk').encode('utf-8'); 
     for f in files: 
       f = f.strip()
       f = f.split('.')[0]
       #print(f)
       a.append(f)
       #input()
    
  #print(len(a))
  #input()

  ret = pd.read_pickle('factor_depart_size_neu_excess.pkl')
  retroll = ret.rolling(window=400).mean()
  retroll = retroll.shift(2)

  c = ret.columns
  #for x in c:
  #  if (x not in a):
  #    print(x)
  #    input()
  #print('pass')
  
  #for i in range(490, 1215):
  i = idx 
  print(ret.index[i])
  r = retroll.iloc[i, :] 
  r = r.sort_values(ascending=False)
  
  local_factor_list = list(r.index)
  select = []
  select_df = []
  for p in range(len(local_factor_list)):
    f = local_factor_list[p]
    df0 = pd.read_pickle(prefix + f +'.pkl').iloc[i - 250:i+1]
    df = pd.DataFrame(df0.values.T, index=df0.columns, columns=df0.index)
    if (len(select) == 0):
      select.append(f)
      select_df.append(df)
    else:
      isbad = 0
      for j in range(len(select)):
        df1 = select_df[j]
        c = (df1.corrwith(df))
        mc = np.nanmean(c)
        if (mc > 0.7):
          isbad = 1
          break
      if (isbad == 1):
        print('skip')
        continue
      select.append(f)
      select_df.append(df)
      
    #if (len(select) > 5):
    #  break
  #print(select)
  
  res = pd.DataFrame({'factor':select})
  s = str(ret.index[i])[0:10]
  of = output + '/' + s + '.csv' 
  res.to_csv(of)
    
          
        
        
    


    



if __name__=="__main__":
    args = argparse.ArgumentParser(description = 'dftotrain',epilog = 'Information end ')
    args.add_argument("--input", type=str, dest='input', default='/data/group/800020/AlphaExperiment/neutral_factor_grow/', help = "input csv")
    args.add_argument("--output", type=str, dest='output', default='FACTORLIST', help = "output pdf")
    args.add_argument("--type", type=str, dest='type', default='raw', help = "")

    args = args.parse_args()#返回一个命名空间,如果想要使用变量,可用args.attr
    d = args.__dict__
    ifile = d['input'] 
    ofile = d['output'] 
    tp = d['type'] 
    base = os.path.basename(ifile).split('.')[0]
    
    
    #sig_csv = pd.read_csv(ifile, index_col=0, low_memory=False).apply(pd.to_numeric, errors='coerce')
    #sig_csv = pd.read_pickle(ifile)

    fs = factorlist(d['input'], d['output'], int(tp))
    
    #LoadFactorScore(d['input'], d['output'], d['type'])
    
