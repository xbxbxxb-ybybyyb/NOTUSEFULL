fetch high frequent market data


